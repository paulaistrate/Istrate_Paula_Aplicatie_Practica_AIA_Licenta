# Sistem de Asistență Decizională pentru Mentenanță Predictivă (Human-Centered XAI)

## Autor
**Istrate Paula** - Facultatea de Automatică și Calculatoare, UPT (Sesiunea Iulie 2026)

## Descriere
Acest proiect reprezintă componenta practică a lucrării de licență. Aplicația implementează un sistem inteligent de mentenanță predictivă bazat pe algoritmi de Machine Learning (XGBoost) și tehnici de inteligență artificială explicabilă (SHAP), conform metodologiei descrise în lucrare. Sistemul oferă operatorilor un dashboard interactiv pentru monitorizarea stării utilajelor și generarea de recomandări acționabile (scenarii "What-If").

## Repository
Adresa codului sursă: [LINK_GIT_AICI]

## Structura Proiectului
- `/app.py`: Interfața dashboard dezvoltată în Streamlit.
- `/models/`: Modelul XGBoost antrenat și serializat (`xgboost_model.pkl`)[cite: 3].
- `/data/`: Setul de date AI4I 2020 preprocesat[cite: 2, 3].
- `/requirements.txt`: Lista bibliotecilor necesare pentru execuție.

## Instalare și Lansare
1. **Cerințe:** Python 3.10 sau mai nou.
2. **Creare mediu virtual:**
   ```bash
   python -m venv env
   # Activare (Windows):
   .\env\Scripts\activate