{
 "cells": [
  {
   "cell_type": "markdown",
   "id": "62ff7e19",
   "metadata": {},
   "source": [
    "# 02_training.ipynb\n",
    "## Echilibrare (SMOTE) și antrenare modele pentru mentenanță predictivă\n",
    "\n",
    "Acest notebook aplică SMOTE pe setul de antrenare, antrenează Logistic Regression, Random Forest și XGBoost, evaluează performanța pe setul de test și salvează modelul XGBoost."
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 1,
   "id": "4387c33d",
   "metadata": {},
   "outputs": [],
   "source": [
    "# Importuri și configurări generale\n",
    "import os\n",
    "import pandas as pd\n",
    "import numpy as np\n",
    "import matplotlib.pyplot as plt\n",
    "import seaborn as sns\n",
    "from sklearn.linear_model import LogisticRegression\n",
    "from sklearn.ensemble import RandomForestClassifier\n",
    "from xgboost import XGBClassifier\n",
    "from sklearn.preprocessing import StandardScaler\n",
    "from sklearn.metrics import confusion_matrix, f1_score, recall_score, roc_auc_score\n",
    "from imblearn.over_sampling import SMOTE\n",
    "import joblib\n",
    "\n",
    "# Setăm tema grafică și reproducibilitatea rezultatelor\n",
    "sns.set_theme(style=\"whitegrid\")\n",
    "RANDOM_STATE = 42\n",
    "np.random.seed(RANDOM_STATE)"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 2,
   "id": "81ff3ce3",
   "metadata": {},
   "outputs": [
    {
     "name": "stdout",
     "output_type": "stream",
     "text": [
      "Folderul models este gata: c:\\Users\\paula\\OneDrive\\licenta_mentenanta\\models\n"
     ]
    }
   ],
   "source": [
    "# 1) Creăm folderul models dacă nu există deja\n",
    "models_dir = 'models'\n",
    "os.makedirs(models_dir, exist_ok=True)\n",
    "print('Folderul models este gata:', os.path.abspath(models_dir))"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 3,
   "id": "ce2258ef",
   "metadata": {},
   "outputs": [
    {
     "name": "stdout",
     "output_type": "stream",
     "text": [
      "Dimensiuni:\n",
      "X_train: (8000, 12) y_train: (8000,)\n",
      "X_test: (2000, 12) y_test: (2000,)\n",
      "Primele 5 coloane: ['Air_temperature__K', 'Process_temperature__K', 'Rotational_speed__rpm', 'Torque__Nm', 'Tool_wear__min']\n"
     ]
    }
   ],
   "source": [
    "# 2) Încărcăm datele preprocesate rezultate din Pasul 2\n",
    "X_train = pd.read_csv('data/X_train_preprocessed.csv')\n",
    "X_test = pd.read_csv('data/X_test_preprocessed.csv')\n",
    "y_train = pd.read_csv('data/y_train_preprocessed.csv')\n",
    "y_test = pd.read_csv('data/y_test_preprocessed.csv')\n",
    "\n",
    "# Convertim y la Series dacă este un DataFrame cu o coloană\n",
    "if isinstance(y_train, pd.DataFrame) and y_train.shape[1] == 1:\n",
    "    y_train = y_train.iloc[:, 0]\n",
    "if isinstance(y_test, pd.DataFrame) and y_test.shape[1] == 1:\n",
    "    y_test = y_test.iloc[:, 0]\n",
    "\n",
    "# XGBoost nu acceptă caracterele [ ] < > în numele coloanelor\n",
    "safe_columns = {\n",
    "    col: col.replace('[', '_').replace(']', '').replace('<', '_').replace('>', '_').replace(' ', '_').replace('/', '_').replace('%', 'pct').replace('-', '_')\n",
    "    for col in X_train.columns\n",
    "}\n",
    "X_train = X_train.rename(columns=safe_columns)\n",
    "X_test = X_test.rename(columns=safe_columns)\n",
    "\n",
    "print('Dimensiuni:')\n",
    "print('X_train:', X_train.shape, 'y_train:', y_train.shape)\n",
    "print('X_test:', X_test.shape, 'y_test:', y_test.shape)\n",
    "print('Primele 5 coloane:', X_train.columns[:5].tolist())"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 4,
   "id": "a7a63f1d",
   "metadata": {},
   "outputs": [
    {
     "name": "stdout",
     "output_type": "stream",
     "text": [
      "Dimensiune după SMOTE: X_train_res= (15458, 12) y_train_res= (15458,)\n"
     ]
    },
    {
     "data": {
      "text/plain": [
       "['models\\\\scaler.pkl']"
      ]
     },
     "execution_count": 4,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "# 3) Aplicăm SMOTE exclusiv pe setul de antrenare pentru a evita data leakage\n",
    "smote = SMOTE(random_state=RANDOM_STATE)\n",
    "X_train_res, y_train_res = smote.fit_resample(X_train, y_train)\n",
    "print('Dimensiune după SMOTE: X_train_res=', X_train_res.shape, 'y_train_res=', y_train_res.shape)\n",
    "\n",
    "# Standardizăm datele de antrenare pentru Logistic Regression și transformăm testul similar\n",
    "scaler = StandardScaler()\n",
    "X_train_res_scaled = scaler.fit_transform(X_train_res)\n",
    "X_test_scaled = scaler.transform(X_test)\n",
    "\n",
    "# Salvăm scalerul pentru inferență ulterioară\n",
    "joblib.dump(scaler, os.path.join(models_dir, 'scaler.pkl'))"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 5,
   "id": "d9896877",
   "metadata": {},
   "outputs": [
    {
     "name": "stdout",
     "output_type": "stream",
     "text": [
      "Modele antrenate: ['Logistic Regression', 'Random Forest', 'XGBoost']\n"
     ]
    },
    {
     "name": "stderr",
     "output_type": "stream",
     "text": [
      "c:\\Users\\paula\\AppData\\Local\\Programs\\Python\\Python314\\Lib\\site-packages\\xgboost\\training.py:200: UserWarning: [13:57:56] WARNING: C:\\actions-runner\\_work\\xgboost\\xgboost\\src\\learner.cc:793: \n",
      "Parameters: { \"use_label_encoder\" } are not used.\n",
      "\n",
      "  bst.update(dtrain, iteration=i, fobj=obj)\n"
     ]
    }
   ],
   "source": [
    "# 4) Definim și antrenăm modelele: Logistic Regression, Random Forest și XGBoost\n",
    "models = {}\n",
    "\n",
    "# Logistic Regression - baseline\n",
    "lr = LogisticRegression(random_state=RANDOM_STATE, max_iter=1000)\n",
    "lr.fit(X_train_res_scaled, y_train_res)\n",
    "models['Logistic Regression'] = lr\n",
    "\n",
    "# Random Forest - algoritm robust pentru date mixte\n",
    "rf = RandomForestClassifier(n_estimators=100, random_state=RANDOM_STATE)\n",
    "rf.fit(X_train_res, y_train_res)\n",
    "models['Random Forest'] = rf\n",
    "\n",
    "# XGBoost - model performant pentru date structurale\n",
    "xgb = XGBClassifier(use_label_encoder=False, eval_metric='logloss', random_state=RANDOM_STATE)\n",
    "xgb.fit(X_train_res, y_train_res)\n",
    "models['XGBoost'] = xgb\n",
    "\n",
    "print('Modele antrenate:', list(models.keys()))"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "5a10e638",
   "metadata": {},
   "outputs": [],
   "source": [
    "# 5) Funcție utilă de evaluare pentru fiecare model\n",
    "def evaluate_model(model, X_test_for_model, y_test, name):\n",
    "    y_pred = model.predict(X_test_for_model)\n",
    "    cm = confusion_matrix(y_test, y_pred)\n",
    "    tn, fp, fn, tp = cm.ravel()\n",
    "    recall = recall_score(y_test, y_pred, zero_division=0)\n",
    "    specificity = tn / (tn + fp) if (tn + fp) > 0 else 0.0\n",
    "    f1 = f1_score(y_test, y_pred, zero_division=0)\n",
    "    try:\n",
    "        y_proba = model.predict_proba(X_test_for_model)[:, 1]\n",
    "        roc_auc = roc_auc_score(y_test, y_proba)\n",
    "    except Exception:\n",
    "        roc_auc = None\n",
    "    print(f'-- Evaluare model: {name} --')\n",
    "    print('Matrice confuzie:')\n",
    "    print(cm)\n",
    "    print(f'Recall (Sensibilitate): {recall:.4f}')\n",
    "    print(f'Specificitate: {specificity:.4f}')\n",
    "    print(f'F1-score: {f1:.4f}')\n",
    "    if roc_auc is not None:\n",
    "        print(f'ROC-AUC: {roc_auc:.4f}')\n",
    "    plt.figure(figsize=(4, 3))\n",
    "    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues')\n",
    "    plt.title(f'Matrice confuzie - {name}')\n",
    "    plt.xlabel('Predicție')\n",
    "    plt.ylabel('Adevărat')\n",
    "    plt.show()\n",
    "    return {\n",
    "        'confusion_matrix': cm,\n",
    "        'recall': recall,\n",
    "        'specificity': specificity,\n",
    "        'f1_score': f1,\n",
    "        'roc_auc': roc_auc\n",
    "    }"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 7,
   "id": "d1985bb7",
   "metadata": {},
   "outputs": [
    {
     "name": "stdout",
     "output_type": "stream",
     "text": [
      "-- Evaluare model: Logistic Regression --\n",
      "Matrice confuzie:\n",
      "[[1872   60]\n",
      " [   2   66]]\n",
      "Recall (Sensibilitate): 0.9706\n",
      "Specificitate: 0.9689\n",
      "F1-score: 0.6804\n",
      "ROC-AUC: 0.9894\n"
     ]
    },
    {
     "data": {
      "image/png": "iVBORw0KGgoAAAANSUhEUgAAAYUAAAFACAYAAABTBmBPAAAAOnRFWHRTb2Z0d2FyZQBNYXRwbG90bGliIHZlcnNpb24zLjEwLjgsIGh0dHBzOi8vbWF0cGxvdGxpYi5vcmcvwVt1zgAAAAlwSFlzAAAPYQAAD2EBqD+naQAANXBJREFUeJzt3QecTFf7B/Bnd5UtLKvtKtF7C8LGEqILIVGDICHK6myCaHmVEKItG70FeYkWQkL03ltEomR1qweL6G3/n9/xv/POnZ1lZosp9/f1mc/YmTszd+7ce55znnPOvR4xMTExQkREJCKe3ApERKRhUCAiIhMGBSIiMmFQICIiEwYFIiIyYVAgIiITBgUiIjJhUCAiIhMGhf/HOXyU1LiPkStwmaDQsmVLKVCggDRt2jTOZcLCwtQyffr0seu9Dxw4IO3bt3/lct999516f3dy5coVad68uRQrVkxCQkLkwYMHifK++A2qVKkir3P/wO11uHDhgtoPli5davNrJk2aJDNnzkzUfUk7JsxvBQsWlFKlSkmDBg1k+fLl4m7is+3JPsnEhXh6esqhQ4dUQRYUFKR77v79+7Jp06Z4ve/ixYvl1KlTr1yucePGUqFCBXEnc+bMUdt01KhREhgYKD4+Ponyvp06dZJPPvlE3FGmTJlk4cKFkj17dptfM378eOnSpUui70uFCxeWgQMHmv5+9uyZOj5mz54tvXv3lrRp08q7774rRt725MZBAQfAyZMnZfXq1dKqVSvdcwgIKND8/f2T7PMRiCyDkau7deuWOtBq166dqO/rzgdtihQppESJEk6xL6VKlcrqulSsWFG1/FCjdqegkBjbntwkfQS+vr5qB0dQsLRq1SqpWbOmJEumj3M3b96UwYMHS+XKlaVo0aISHBwsnTt3Vs1QLc2xbNkyuXjxoqlZqjVRv//+e3nvvffkzTfflJ9++slqk//nn3+W+vXrq2UqVaokY8aMkcePH5uej4yMlNDQUNWkxw2fHRUV9crvumXLFpUqwwHwzjvvyH/+8x+5c+eO6fmzZ89Kt27dpHz58moZpBKQBtNo3+G3335Ty5UsWVJ99wEDBqhWFSC9g+976dIltSy+H/7G/7Xto8GyWlpOW8baTVvGWvoILbL3339f/Q7YVvg81Gxfpx07dsjHH38sb731lrz99tvyxRdfyOXLl3XL/P777yqlhu2K9URrCpUQ7btZpjCeP38u4eHh6vviu+Ee+8GTJ0/U89o+M2HCBNP/47Mv2SNlypSqAPXw8DA9hvWcNm2aVK9eXa0njpcffvgh1muR5qpataoUL15c7YMbN25U67pnzx7TuuM98H2wT2H/vH37tk2/MY5HbHPst0hZfvjhh+p7m6/jy7altfRRYhwL5KJBAVCj1VJImrt378rWrVulTp06sTr2UCCjIOjZs6fa2dGE37Vrl6nJjTQHAk3GjBlVsxQ7sgY7dLt27WTkyJFqh7M0b948+fLLL6VIkSLqAEG/BA6yoUOHqufPnDmjDqobN27It99+K8OGDVMBoVmzZuqxuKDVg/VOnz69jBs3Tq37+vXrVZ8JoLWEnDF2duzYo0ePVgf/p59+Knv37tW9F75n1qxZVU67TZs2smTJEpk8ebJ6Duts/t2R0rAFthGWN78heCIgo1CzZurUqfLVV1+p2uuUKVNUoTt9+nT12OuCwuezzz6TzJkzy9ixY6Vv374qADRp0sT0eyCNqLVCsUzXrl1VQWpeyFjC9/jxxx9VwJ81a5b6fbGvadsZ2wcaNWpk+r+9+1JcsI8/ffrUdHv06JGcPn1afbd79+6pQlczaNAgiYiIkA8++ED9BvjNvvnmG5k4caJpGXw29qdatWqpfQYBqkePHrE+FxUJVFxQgOOz0qRJY9Nv3KtXL7WNUVHDc2j943vv3r3bpm1pKbGOBXLR9JFWICFNZJ5CWrdunSpAUfszd+3aNbUsdrrSpUurx1A7PH/+vOngRJojXbp0umapVnvAgdGwYUOr64EaDQ6matWq6Q5cdNSuXLlS1WxwgOHzkd9FMx9wwOA1M2bMUOtlDYJRoUKF1Ou1mh7WD3np69evq8fx99y5c03vi+2CoIgAhp1dg0Jf+xx8NgLk5s2bVW0NB6Tld7cFXoObBtt/zZo10q9fP7V9Lf3777/qQEThiwMXULtEvht/t27dWvLlyydJCb8XCgx8LmqeGrTeUNFAwYMcPAq21KlTq99H61/JnTv3Swc4oPBBrVbbV1ALxWvxPqBtW6SLrG1nW/al5MmTW/3sffv2qUBiDvtM/vz51f6CFrJWQVm0aJF8/vnnpkEV2BZYFt8ZrSe0LlAoozBHRURbButhGcwQgMyPK1t/Y2wrFPj4rtq2wjLYB23ZlpYS61ggF24peHt7qyaleQoJBw4KcPOmMqDjFDsLggVqEtgJUPs6ePCgTc1yFMxxwUGG2iWa0eZQA0HTFgcxaj/YqbHOWk0OOy4OpJ07d1p934cPH8rRo0fVQWP+fVBwoeDNkCGDOnBwsGsHAaCWjmb7X3/9pWqIGstCCAVTYjaZjx8/rgrTevXqxdmxjNo4vhd+N/NarZZewu9iDQpL8+UTkmrC7/XPP//Eak2iUoB0glarxG+GfLx5hzueRw0zLgiEWloKwQS11xYtWuhq6a9at1ftS3FBQEDBhxsKZQSDnDlzqhYmWgIafC+0Kqz9BmhdoCWEFjh+J/PXgeU2s3Z82PobY1uh0oM0DlJNqOSgoEZwjs+2dKZjwV24XEsBEACQBkIKCbUbpIOsNXFhxYoVKg2AvDFqJNiRUUjb2ofxsg5aQAvlZcugrwM3S+Y1bXPIzeLgfdn7YhkEB0t4DK9FOk1jOZoII7gSa7w8CrKOHTuqmjTSAa/aVnEN+0WLzhq0PNDfo0HBjPx2fGjrENd2QyDWct7Wtr2112natm0rfn5+qt8JrRGM5EKtGDXksmXL2rxuL/vN44LPRW5eg3QP0kNIkyGgaPuZ9hkoLK25evWqSgFZ2zfjWi98tr2/MdJNSC0hv49KDvbHcuXKyZAhQ9Tva++2dJZjwZ24ZFBATQ47DloLKLizZcummpyW9u/fr2oh6HhCrQstB0Cz8mU5Yltoo5xQiJiLjo5WBQxql2jyYodH09mSZYe4BjUetBAs3xe1OdT2cNDj4EUNyxJqwhAQEBBnQfsqWusEtXRz5jUuQEsLaQCsF1IfCM6v2lY4yFGLtbXAReBHKkOjpRjiAxUCiGu7YZtptUdryyAAIvhZg8IF64kblkOuHQUf+iNQ633VetuyL72sgmK5LTEooXv37qoPS0uVaZ+BTnPzwlyTJUsW1WKx9l0t1yshvzGOCfQr4Ia+jw0bNqgWDioV6Lt51ba0lJTHglG5XPoIcJAhvYKaBmoccdV+0KRF4YYdSgsISEFoqRut4MOOaC8cNNjhLOdGYMIQakvIAyN1hOYvWieozeGG4IU+BuThrcEBi+Ut3xcd6Xhf7OBlypRRz5vXgvC9kEbDZySk8NSa4eYd+egY1GqC5p12aJ6j4/JVQysRyJACQW1U2w64ITCiFWc50kmDYG++fEIme+XKlUt1qP/666+6x9Hxj7SJlr7Att22bZsKdhoUzHGtI6C/QesLQK0aHZ8o1DBaTPuNXraP2bIv2QPpH8yBwHfV0mJa7h+BxnybosBH3wN+X0x8Q6FtuW+uXbv2lZ9py2+MEX7mowfxvTGQAxUndFzbui3NJeWxYFQu2VLQcuwYoYODTevYsoQhdYCmKTqu0NTEKA/kwQH5RBSCqOWgtoFaycv6Ecx5eXmpYIP3xs6L3ClqWigksROjBoORTdjJsZ4YRYHaNDrsMJIIy8UF+VakZdApiFw91g0HFgIhcsaoQSNIIIePQgMH43//+19VwCEPmxDI6SK9NmLECFXbRAsB66rVtAFBDakJpCjQJEehqsFBiA5scyjwkBZA4YODF5+BwgN/o2WCwigxaJO2LGGboeDB9sRIGXQsIsWCAhIdlfittNZchw4dVLoP64vvh8II64n9zLLPyrxgwkgZ1IZRq8d3w3BmVAq0VAz2MfRloWNYK6Dt2ZfshdQbviMKWKTgEFDxN0YCoXBG5QSfgXQOgi9q91gPfG98Ln5XrD+CCkYDvSqw2fIbI+CgAoF1wjLoz0HFAscdjhFbtqVlH0BSHgtG5bJBAQc5DjQML8yTJ4/VZbBjoimNnQq1E+xoeAwFAVIfSCGh5oLaCHZMPIYC2daJXDhg0azHyBUU9tjhUfPBDXAgIAjhwENnLPKXKKCQbsE48Lig4wxNZm09cTDUrVtXFRyAHOv8+fNNwypx0CEAolPdssCxF7YpOgKRdsBnI8+LA898LDma/ICDFzdzceX90eeDmjrWGwcrCjqMAEFBHdfIEnthVNnw4cNjPY6hoNhf8DujJYbRNvhuqBCgRo11wLpBjhw51O+JFCP2BRTSKLAwdNFa2gUQPBEMkQfHb4vvg4LdfFQLgg3SJNg3rPUxvWpfshdq4Uib4vdBoY7OWmwbfPcFCxaoAIrvhn0dvw0CAuC7Yj/FOmBd0ALASCS89lUpLFt+Y+zT2G8RLBCUcfxi/9L6ImzZluaS8lgwKo8Y9rQQmWDQAmqb5gUKWgsIKgjs7nrqDsBoIaScUHFCYa1BxQa1e0xeS8ozBpBzcNmWAlFSOHLkiEqfoHaL4Z7ItaOliRprXEMz3QXy/5ingM5opC+REsKMfAxvRRqTAcEY2FIgMoPBB0jdoZMXw5iRMkE+G+kLpJbcHXLxSMWgVYAWEkYloS8CaaWXzZcg98GgQERErj0klYiIkgaDAhERmTAoEBGRCYMCEREZb0iqT8n/XQqR3N+1XXHPGCf3k9rb87WVDQ9+nyDuzDBBgYjIKg8mTMwxKBCRscVxTiujYlAgImNjS0GHQYGIjI0tBR0GBSIyNrYUdBgUiMjYPF+cNpxeYFAgImNj+kiHQYGIjI3pIx0GBSIyNrYUdBgUiMjY2FLQYVAgImNjS0GHQYGIjI0tBR0GBSIyNgYFHQYFIjI2T577yByDAhEZGyev6TAoEJGxMX2kw6BARMbG0Uc6DApEZGxsKegwKBCRsbGloMOgQETGxpaCDoMCERkbWwo6DApEZGxsKegwKBCRsbGloMOgQETG5sli0By3BhEZG1sKOgwKRGRs7FPQYVAgImNjS0GHQYGIjI0tBR0GBSIyNrYUdBgUiMjQPBgUdBgUiMjQGBT0GBSIyNh44TUdBgUiMjRPT09Hr4JTYVAgIkNj+kiPQYGIDI1BQY9BgYiMjX0KOgwKRGRobCnoMSgQkaExKOgxKBCRoTEo6DEoEJGhMSjocYAuERmbh523RDJ16lRp2bKl7rEBAwZIgQIFdLcqVaqYnn/+/LlERERIhQoVpESJEtKuXTuJiorSvcexY8ekRYsW6nm8du7cuXatF4MCEYnRWwr23BLDvHnzZNy4cbEe//vvv6VDhw6yfft2023JkiWm5ydNmiTz58+Xr7/+WhYsWKCCRNu2beXx48fq+ejoaGndurVkz55dfvrpJ+ncubOMHj1a/d9WTB8RkaG9zhnNV69elYEDB8qePXskZ86cuudiYmLk5MmT0r59e8mYMWOs16LgnzVrlvTs2VMqVaqkHgsPD1ethrVr10qdOnVk0aJFkjx5chkyZIgkS5ZM8uTJI+fOnZNp06ZJw4YNbVpHthSIyNheY/royJEjqtBesWKFvPnmm7rnzp8/L/fv35fcuXNbfe3x48fl3r17EhISYnrM399fChcuLPv27VN/79+/X4KDg1VA0JQtW1bOnj0r169ft2kd2VIgIkOzNyVUtWrVlz6/YcOGOJ9Djt+8j8BcZGSkuv/hhx9k69atqgVTsWJFCQsLk9SpU8uVK1fU85kzZ9a9LlOmTKbncJ8/f/5Yz8Ply5clQ4YMr/x+DApEZGjOMvooMjJSBQIU4lOmTFEth5EjR8qJEydkzpw58uDBA7VcihQpdK9LmTKl3L59W/3/4cOHVp+HR48e2bQeDApEZGj2BoUNL2kJJETHjh3l448/loCAAPU3avzoW/joo4/kzz//FG9vb1PfgvZ/rbD38fFR/8fjWqez+fPg6+tr03qwT4GIDM0Ro4+sQStBCwiafPnymdJCWtro2rVrumXwd2BgoPp/UFCQ1edBW+ZVGBSIyNgcNE/BUu/evaVVq1a6x9BCgLx580rBggUlVapUauSS5s6dO3L06FEpU6aM+hv3Bw4ckGfPnpmW2b17t+TKlUvSp08vtmBQICJDc5aWQs2aNWXXrl0yYcIE1Z+wZcsW6devnxpqiqGl6CvApDTMO0AKC6OR0AmN1kGNGjXUe2DY6d27d6V///5qeOvSpUtl9uzZEhoaavN6sE/BRWTNlFb2L+knH4VNl20HTpgeL18yjwzuUleK5c8qt/99ICs2/SGDJv4qd++/yCOumd5dKpZ+0QS1xqdkF3Wf2s9b+rWvJR9ULi6BGfzlzIUbMn3xNpm+ZLsaP03O48/Dh2TC+HA58tefKk8cUv4d6R7WS9L9f00w6vw5GTtqhPz++wHx8vKSatVrStcePVUtk5y3o7lq1apqQhvmFEyfPl2NOKpbt6706NHDtEy3bt3k6dOnauYzOpXRMpg5c6Ya5gpoDcyYMUOGDRsm9evXV30SaIHg/7byiDHIEa8Vfq4oW2BaWTGpsxTKnVlqtB1vCgqFcgfJzvlfys5Dp2Tc3A2SJVNaGda9nuz+47Q06jFVLVMwd5D4+/2vUwpyZ8sgM77+RGYu3SHdv1moHvt5Qkd5q3AOGTpllfx99opUDi4gX7SqLkOnrpIR01eLq7m2K0Lc0bGjR6Rtq+YS/HaINGnWQv7555pMiBgrWbNmk1lzf5R/79yRpo3rSfr0GeSzdqESffOGRISPkaLFist3k6eLu0rtHf+kxxtdltu1fNSED8WdsaXg5DWY5nWCZXhYfau1maa1y6ha/Edh0+TegxcjDpJ5ecqEAc0ke+YAOX85Wo6ffjF+WePp6SFjejeSw5EXpefIF9PnSxTMJjXLF5HmvWbK0vW/q8c2742UtP6+8vmn1VwyKLiriPDRUqBgIRkzfqJpJq6fn5+MGTlcLl64IGvXrJLbt27JvAU/Sdr/77TMFBgk3TuHyqHfD0qJkqUc/A2cj7O0FJwF+xScWLF8WeS7/k1l/sq90uarObGe906ZXJ48fSb3Hz4xPXbz9j11ny6Nn9X3bNvwHSlZKLt0G7ZAvVYzY8l22bT3b92ykWeuqrRSpnSpE/FbUXzduhUtB/bvlUYfNdOdmqFKtRqycu0myZotm+zauV1KlnrLFBCgbEh5FTh2bN/Kje/EfQrOwqEtBeTGcM4OTNHGbDuMr8V4WwydQq4MnSfIiRpV1JVoKfrBYLl47ZZUeCt2v8Ccn3dJq3ohMvKLBjJ8+moJTJ9a+rWvLX9GXlQtAUt+Pinkq47vqyCz/8g50+OHjl+QrsMWxFq+buXicu3mv/JP9N0k+HZkr5ORkeoEaAEB6WRA316ydfNGQfK3ctVq0uvL/pLa31/Onj4t1WvW0r0Ox1CWrNnk3Nkz3OhWGKGgd4mWwoULF+T9999Xves4MyAmXaBTBB0m6FXv27ev6mS5dOmSGFX0nfsqIMTl6KnL0n/8cunY9F25uPlbOfjTAEntl1IadJssz5/H7ir6tF6IBPj7ysiZa1/52Z2bVZJ3y+SXMd+vY0ezk4iOvqnuhwzsr2apjh43Qbp/3ku2bdksPbp2VL/T3bv/il+q2K1EX18/uXeXwd0athScpKWAs/hly5ZNnRYWveyWMP4Ww62wHKZ8U2w9W1eXr7t9KFMWbJGfN/4hGdL6SZ92tWTV1G5S7bNwVcs3F/pRRVm55U85eV4/ucVShyYVZWTPBrJkzQGJ+O9Gbnon8eTJizRhwcJF5KtBQ9X/0eGM46d/n56yZ9dOq5UBR5wN1KWwoaDjsL0EKSMMlbIWELSz//Xq1ct09j/S8/LylD7t3pMfV+6VsG8Xy5Z9kfLTut+ldmiEBGXwl7BPq+mWL5ovi+TPGSgLftv30hrTiM/rS3ifj2TR6gPSqn/sfgxyHF+/Fy2AChVfnDZZU658BXV//PhRSZU6ldy/dz/Wa+/du8shqXFgS8FJggKCAc4t/jJIHZmf44P+J2NAKvHzSSm7/jit2yzI/0eeuyaF8gTpHq9Voajce/BIftt2xOpmTJ7MS+aPaiPdW1ZVw1tb958jz5495yZ3Itmz51D3lue2Qd8ceKf0lhw5cklU1P/6iwCzWy9dvCA5c+d5jWvrOhgUnCQoNGrUSPr06SMLFy5UF4HQdnTc4/JyuFIQZuU1aNDAUavo1JAaunHrnpQvmVf3ePq0fpIve0Y1+cxccPFccuhYlDx89L+RSuamD2mpJq71GrVE+oYvS9J1p/jJlTuPZMmSVQ07NZ9etGXzixRfiVJvSdmQcnJw/36Jvvmi/wF279qhztOPUUgUG/qZ7bm5O4f1KXTt2lXlOHFqWOywljCErnnz5tK9e3eHrJ+zQ+546JSVKtVz595DWbruoGRIm0p6flZDnj2PkfE/6M/kWDRvZlm/67jV96pTqZg0qVVaftl8WPb+eVaCi+mvCIXRSY+fvKiNkmNrtN0+7yV9e4VJv96fS72GjeXMqVMyacI4NSy1YKHCEhgYJAsXzJPOHdpIu9BOcvv2LTV5rdw7FeTNEiX581mBuTvkBEEBO3iXLl3UOTlwoWmkknC+cKSLcC4PnPzJ8rzgpDdl4Va59e8D6d6yinzywduq5bDj91PS5PPpcu6SvqWQKZ2/3Po3dvCFelVLqPu6lYqrm6UCtf8j5y//r+ZJjoNTVqQcP1GmT50sYV07in+aNNKwcVPp2OVF5SkgXTqZMn22jB01XAb06y1+vn5StXpN6fFFb/5sceCQVD2e5oLckrue5oIS/zQXBfussWv54yNquvXPwNNcEJGhMX2kx6BARIZmhM5jezAoEJGhsU9Bj0GBiAyNLQU9BgUiMjS2FPQYFIjI0BgU9BgUiMjQOPpIj0GBiAyNfQp6DApEZGhMH+kxKBCRobGloMegQESGxpaCHoMCERkaWwp6DApEZGhsKegxKBCRobGloMegQESGxpaCHoMCERkaWwp6DApEZGic0azHoEBEhsb0kR6DAhEZGoOCnt0XNp0wYYJcvXrV6nMXLlyQIUOG2PuWREQO7VOw5+bu7A4KEydOjDMo/PHHH7J48eLEWC8iotfWUrDn5u5sSh81bdpUFfgQExMjTZo0iXPZYsWKJd7aERElMQOU84kfFIYOHSqrV69WAQEthYYNG0pQUJBuGU9PT/H395caNWrYtwZERA5khNp/ogeFvHnzSpcuXUwbsHHjxhIYGGjXBxEROSPGhASOPtKCw40bN+Tx48eq9QDPnz+XBw8eyP79+6VZs2b2vi0RkUN4MiokLCgcP35cevbsKadOnbL6PFoSDApE5Co4eS2BQWHkyJFy+/Zt+fLLL2XTpk2SIkUKqVy5smzdulXd5s6da+9bEhE5jCe7FBI2JBWjkLp37y6tWrWS2rVrq5TRxx9/LFOmTJFq1arJDz/8YO9bEhE5DIekJjAooB8hZ86c6v+4RzpJ06BBAzl06JC9b0lE5DCcvJbAoJAlSxaJiooyBYW7d++qmcyAVBJSS0RErsLDzn/uzu6ggHkIY8aMkTVr1qhhqblz55Zx48bJ33//LbNmzZI33ngjadaUiCiJ+hTsubk7z/gMSS1VqpQsWbJE/d23b19Zt26d1KtXT3bv3i1du3ZNivUkIkoS7FNI4Ogj9ClERETIkydP1N8VKlSQX3/9Vf766y8pUqSIZM+e3d63JCJyGE5TSGBLASOOVq1aJcmTJzc9hpRRrVq1GBCIyCUnr9lzc3fxaikEBAQkzdoQEb1mnLyWwKDwySefqI5lb29vKViwoPj4+Nj7FkRETsMAlf+kDQrLly+XS5cuqQlrcXXaHD161N63JSJyCCOkhJI0KHzwwQf2voSIyGkxJCTSWVKJiNwBr6eQwNFH8OjRIzl8+LA6Tfa+ffvUbc+ePbJ582YZPXp0fN6SiMhQk9emTp0qLVu21D127NgxadGihZQoUUKqVKkS6wSjuEQBpgRgKgCWadeunekME7a+R6K0FE6cOCH58uVT/0fhjxPixXU6Cz8/P3VqbSIiV+CIlsK8efPUgJ3SpUubHouOjpbWrVurgnzw4MHqPHK4R5mKq13CpEmTZP78+TJixAh19ctRo0ZJ27Zt5ZdfflGnGbLlPRIlKOBDcXrsQYMGSXh4uBqSOmTIEFm5cqWKXLgS2/bt29UXnT59eny3ExHRa/c6Y8LVq1dl4MCBqnKtnVhUs2jRIjX/C2VrsmTJJE+ePHLu3DmZNm2aKtAxHQCnEkKlu1KlSuo1KI/Rali7dq3UqVPnle+RaOkjND8WLlwo165dU+c4Qr8CzoGEaHTx4kWpWLGi9OvXT5o3b64iGRGRq3idp7k4cuSIKrRXrFghb775pu45pOODg4NVYa4pW7asnD17Vq5fv67OSH3v3j0JCQkxPe/v7y+FCxdWKXxb3iPRWgqYkwC4dgJaBtr1mRHpcAU2PObp6almNfPcR0TkSrzs7CioWrXqS5/fsGFDnM+hIo2bNVeuXJH8+fPrHsuUKZO6v3z5snoeMmfOHGsZ7blXvUeGDBkkUVoKffr0keLFi0uOHDnUqSzQWtCCAjqdT548qf7G+ZAQyYiIXIWHnbek8vDhQ9UvYC5lypTqHuUsKuVgbRk8b8t7JFpLAakinAVVm6eAEUZPnz6VTz/9VPVwDxs2TP1/xowZkjdvXps+mIjIFSevbXhJSyAhkJFBv4E5rSD39fU1ZWywjPZ/bRntzBKveo9ECwrNmjXTdTpj5BGGpMJXX30lbdq0kU6dOkmqVKlk8uTJNn0wEZEzcJYJzUFBQarf1pz2N1L2qIhrj5mfjRp/FyhQwKb3SJLJa+hoMR9yitNlr1+/Xk6fPq0uuIPAQETkKpxl8lqZMmVkwYIF8uzZM/Hy8lKP4Ro1uXLlkvTp00vq1KlV+YqRS1pQuHPnjjqtEOYl2PIeSTJ5rXPnzuqiOtr1FAArij4HBgQicjXOco3mhg0bqssb9+/fX/XTLl26VGbPni2hoaHqefQVoPBH+h4pLIxGCgsLU60DpPhteY8kaSngeswYYZQmTRp577335MMPP1RXYiMickXOckK89OnTq35Z9NHWr19fMmbMKL1791b/13Tr1k2lkQYMGKA6ldEymDlzpun6Nra8x6t4xMTExNi78hiGiqut4WI7mBiRLVs21QGNAIERSs7IpyTP2WQk13ZFOHoV6DVK7R2vM/YonZbad1bnSQ0KizuL15bELDmc6mLNmjWyePFiqV69uvz888+q5dCkSZPEX0sioiTCazQnMH1kCR0eCBLo/cYU7vPnz4szit43wdGrQK/R46fPub3JJl5Okj5y6aBw//59NeII6aMdO3ao2czvvvuuOnsf7omIXEVinvnUkEEBaaOtW7eqTg50MGOeAk5vgeFSRESuhkEhgUEBp7jAObzRsYwOZiIiV+Ys8xRcNiisXr061hRqjJ/lhiUiV8SWQiL0KWD2MvoPdu7cqSZKYATSkiVL1IxmyysJERE5MzYUEjgkFZd6a9SokToveN26dUWb5oAp1d98840sW7bM3rckInLo5DV7bu7O7pbCt99+K0WLFlVXAAJcbQ0www6pJFyQx57Zc0REjhT/aW/uye7tgWt+tmrVSl3Zx7IfoXbt2uoKP0RErsJZzn3ksi0FXLABw1GtuXXrVqwLPBAROTMjpISStKVQvnx51cmsXf4N0GLAFdeQUipXrpy9b0lE5DBenvbd3J3dLYVevXqp8xvhPEcFCxZUAWHEiBFy5swZ1ek8duzYpFlTIqIkwJaCnt1xDxeNXr58ubr8JoIAzn2E017UqVNHnbv7jTfesPctiYgchn0KiTBPISAgQF3cgYjI1XHyWjyCwr59+8QeuPADEZEr8BB2NNsdFDBL2dppLMyvz2P+PCa4ERG5ArYU4hEUMCFNc+nSJXVmVFwLFGdHxeXeMBR148aN6oLRQ4YMseUtiYicAoNCPIJCcHCwrtWAyWtffPGFbhmcRtvb21u+//57NYmNiMgV8GSeCRx9dPjwYQkJCbH6XMmSJSUyMtLetyQicmhLwZ6bu7M7KAQFBcm2bdviPK02hqgSEbkKL08Pu27uzu4hqa1bt5ZBgwbJtWvXpHLlymp46vXr11VA2LRpk4SHhyfNmhIRJQEDlPNJGxSaNm0qT58+lcmTJ8vKlSt1k9owmxkznYmIXAVPfaTnEWM+rjQeF9u5ffu2ai34+Pioi+389NNPqsXgbB4+dfQa0Ov0+OlzbnAD8feO/0mJJu6w78zOncvnFHcWrxnNGlxpDf0LM2bMkC1btqgWBK/bTESuhC2FRAgKN2/eVJffXLRokVy8eFFSpUqlLqzz4YcfSunSpePzlkREDsE+hQQEhd27d8vChQtl/fr18uzZM3nrrbdUUJg4caJuLgMRkavgWVLjERRmz56tggFOj50jRw7p1KmTahn4+vqqYMDJH0Tkqpg+ikdQwPUSChQooE53Yd4i+Pfff215ORGR02JLQc+mLvv3339fzp07J6GhoaqVsG7dOtWpTETk6rw87Lu5O5taCmPGjJG7d+/KL7/8oi6k07VrVzUMtVq1aip1xPQREbkqll+JME/hxIkTaj4CgsSNGzfUqS3QmsAtb9684ow4T8FYOE/BWBIyT2Hu/ii7lv+ktHtfXTJBk9eQQsJENQSI7du3qxFJ+fLlkxUrVoizYVAwFgYFY0lIUPjvgQt2Ld/irWzizhI0eS1ZsmRSvXp1dcP5j5YtW6ZuRESuwgDdBK+vpeBK2FIwFrYUjCUhLYX5B+1rKXxcii0FIiK3xY7mREwfERG5uvi3MdwTgwIRGRpbCnoMCkRkaJzRrMegQESGxvSRHoMCERka00d6DApEZGicp6DHoEBEhsZTZ+sxKBCRoXmyraDDoEBEhsaWgh6DAhEZmgdbCjoMCkRkaGwp6DEoEJGhsU9Bj0GBiAzNk7PXdLg5iEiM3qdgz7+EuHr1qhQoUCDWDZc5hmPHjkmLFi2kRIkSUqVKFZk7d67u9c+fP5eIiAipUKGCWqZdu3YSFWXfleNehS0FIjI0z9c4e+348eOSMmVKWb9+vW4mderUqSU6Olpat26tgsHgwYPl0KFD6t7Pz08aNmyolps0aZLMnz9fRowYIUFBQTJq1Chp27atujRyihQpEmUdGRTcEGoTSxYvlEUL5suFqAuSLn06qVy5qnTs0k1SpUrl6NWjBPrz8CGZOD5cjvz1p/j6+kpI+XekW1gvSZc+vXr+2tWrEjFutOzesU1dMrdw0WLSPayXFChUmNvewaOPIiMjJWfOnJIpU6ZYz82ZM0eSJ08uQ4YMUVe1zJMnj5w7d06mTZumgsLjx49l1qxZ0rNnT6lUqZJ6TXh4uGo1rF27VurUqZMo68j0kRv6fuYMGTHsa6lQsZKM+26ifNrqM/llxXL5okdXMciF9tzWsaNHpGPbVuLj6yujwr+TLj2+kN27dkjPsC7q+Xv37kn7z1pK5PFj0verwfL18FFy/9596dyhjVz/55qjV98pocJuzy0h/v77b1XYW7N//34JDg5WAUFTtmxZOXv2rLrcMVoZ+H1DQkJMz/v7+0vhwoVl3759kljYUnDDVsL3s6ZLo8ZNpHvYF+qxsiHlJE3aAPmyZ5gcPfKXFClazNGrSfEUET5a8hcsJGPGTxTP/+8hRXphzMjhcvHCBflt5Qq5ffuWLF72q2TI+KI2WqhIUfmkaSM5sH+f1Kz1Pre9g1sKAQEB0rx5czlz5ozkyJFDOnbsKBUrVpQrV65I/vz5dctrLYrLly+r5yFz5syxltGeSwwMCm7m7t27Uqfuh1LzvVq6x3Plyq3u0SnFoOCabt2KloP798rAr4ebAgJUqVZD3WDj+rVStVoNU0CADBkyyqr1Wxyyzu7Yp1C1atWXPr9hwwarjyOVd/r0acmbN6/06dNHpXJXrlwp7du3l++//14ePnwYq18A/Q/w6NEjefDggfq/tWVu374tiYVBwc2gOdmn34BYj2/auF7d58mb1wFrRYnhZGSkagkGBKSTAX17ybbNGwXZwMpVq0nPL/uLj4+PnD59Smq9X1cmTxgvy5ctkVu3bkmJEqWkV98BkidvPv4QDmwpJEuWTPbs2SNeXl7i7e2tHitatKicOHFCZs6cqR5Dv4E5BANA35H2Giyj/V9bBr99oq1nor0TOa3Dh/+QWTOmybuVKku+fPrmKbmO6Oib6v7rgf2l3DsVZNS4CRJ17pxMjAhXqaNvx46XZ0+fyvz/zpGsWd+QAQO/VgXI1EnfSWibT+THxcslo5UOTqOzt59gQxwtAVsg1WcpX758sn37djWa6No1fb+P9ndgYKBqaWiPZc+eXbcMhrUmFnY0u7nfDx6QTqFtJWvWbDJk2HBHrw4lwJMnT9R9wcJFZMCgoRL8dog0/Kip9On/H/nj0EHZvXO7admIydPknYqVVFpp/MSpcv/ePVm0YB63vxVeHh523eILLYJSpUqp1oK5v/76S6WUypQpIwcOHJBnz56Zntu9e7fkypVL0qdPLwULFlQpJ/PX37lzR44ePapem1gYFNzY6t9WSWjb1pI5KLNMmzVb0qYNcPQqUQJotUwU9uZCyldQ95cuXlT3b5UOFl/f/9VIgzJnkZy588jfx49x+1vhYectvjDqKHfu3GrIKUYanTp1SoYPH67mI6CzGcNO0SfYv39/OXnypJrQNnv2bAkNDTX1JWBi2+jRo1VrBaORwsLCVAujRo0XfUounz5q2bKlzZfCs5zZRy835/uZEj5mlJQuEyzhERPV5BhybW9kz6Hun1jknbW0QurU/qq/wTIvrZZ58sTUaUkWXtPgI09PT5kyZYqMGTNGevTooWr5GE6KTmZt1NGMGTNk2LBhUr9+fcmYMaP07t1b/V/TrVs39XsPGDBAdUyjhYD+CMxvcIug8M4778j48eNV86h48eKOXBW3snjRAhk7eqTUrFVbhn3zrSRPpJmO5Fi5cueRLFmyyto1q+SjZs1NFaqtmzeq+5Kl3pJyFSrK5o3r5VZ0tKQNeNEyPHv2jJw/d1bqNWjk0PV3Vq9zSGqGDBlU6yAuKAcXLlwY5/PopO7Vq5e6JRWPGAfPZpo3b56KnCtWrJBs2bIl2ec8fFGZcnvX//lH3n+vmprdOmz4SN1EGMj2RnZJly6duLvHT5+LO9qwbo307RUmVavXlHoNG8uZU6dk8oRxUrbcO/LtmPFy4UKUtGzaUPUhtQ3tpPoh8Pyzp89k/pLlVjs63YG/d/wz4XtP2zecMzh3GnFnDg8K0KFDB5Uvw4mekopRgsKypUtk0Ff943x+yNDh8mH9BuLu3DUowLYtm2TG1Mly8sTf4p8mjbxXu6507NLdNH799KmT8t24MWpOg6eXl7xdtpyE9eojgYFB4q4SEhT22RkUyjAoJD0MqTpy5IhUrlw5yT7DKEGB3D8oUCIHhTN2BoVc7t1ScIp5Cpimbe0EUURESY2X43TCoEBE5Ci8HKcegwIRGRqDgh6DAhEZGtNHegwKRGRobCnoMSgQkaG9xqtxugQGBSIyNkYFHQYFIjI09inoMSgQkaGxT0GPQYGIDI3ZIz0GBSIyNkYFHQYFIjI0T+aPdBgUiMjQ2FDQY1AgImNjVNBhUCAiQ+OQVD0GBSIyNHYp6DEoEJGhMXukx6BARMbGqKDDoEBEhsY+BT0GBSIyNPYp6DEoEJGhMXukx6BARIbmwaaCDoMCERkaY4IegwIRGRrTR3oMCkRkbIwKOgwKRGRoHJKqx6BARIbGPgU9BgUiMjRmj/QYFIjI0NhS0GNQICKDY1vBHIMCERmaJ2OCDoMCERka00d6DApEZGgckqrHoEBExsb0kQ6DAhEZGmOCHoMCERka+xT0GBSIyNDYp6DHoEBExsb8kQ6DAhEZGmOCHoMCERmaJzsVdBgUiMjQGBP0PC3+JiIiA2NLgYgMjS0FPQYFIjI0DknVY1AgIkNjS0GPQYGIDI1DUvUYFIjI2BgVdBgUiMjQ2Kegx6BARIbGK6/pMSgQkbExfaTDoEBEhsb0kR6DAhEZGoek6nnExMTEWDxGREQGxXMfERGRCYMCERGZMCgQEZEJgwIREZkwKBARkQmDAhERmTAoEBGRCYMCERGZMCgQEZEJgwIREZkwKBARkQmDAhERmTAoEBGRCYOCG3r+/LlERERIhQoVpESJEtKuXTuJiopy9GrRazB16lRp2bIltzXFG4OCG5o0aZLMnz9fvv76a1mwYIEKEm3btpXHjx87etUoCc2bN0/GjRvHbUwJwqDgZlDwz5o1S7p16yaVKlWSggULSnh4uFy5ckXWrl3r6NWjJHD16lXp0KGDjB49WnLmzMltTAnCoOBmjh8/Lvfu3ZOQkBDTY/7+/lK4cGHZt2+fQ9eNksaRI0ckefLksmLFCnnzzTe5mSlBeDlON4MWAWTOnFn3eKZMmUzPkXupUqWKuhElBrYU3MyDBw/UfYoUKXSPp0yZUh49euSgtSIiV8Gg4Ga8vb3VvWWnMgKCj4+Pg9aKiFwFg4Kb0dJG165d0z2OvwMDAx20VkTkKhgU3AxGG6VKlUr27NljeuzOnTty9OhRKVOmjEPXjYicHzua3Qz6Elq0aKGGJ6ZLl06yZs0qo0aNkqCgIKlRo4ajV4+InByDghvCHIWnT5/KgAED5OHDh6qFMHPmTDVskYjoZTxiYmJiXroEEREZBvsUiIjIhEGBiIhMGBSIiMiEQYGIiEwYFIiIyIRBgYiITBgUiOLA0dpkRAwKlGRwWcgCBQrobkWLFlUX/xk8eLDcvn07ST536dKl6rMuXLig/v7uu+/U37bCKcbbt28vFy9eND2GU1P36dMnSdaXyJlwRjMlKVzcZ+DAgaa/nzx5oi4KM3bsWDl27Jj8+OOP4uHhkaTr0LhxY3W9alvt3LlTtmzZontswoQJ6pxSRO6OQYGSFArSEiVK6B7DaTdwdbiIiAj5448/Yj2f2HDeJ9wSGtyIjIDpI3IIpJHg0qVLKs3Us2dPdc4mBIjWrVubrgExcuRIeffdd9XydevWlVWrVune5/nz5zJp0iSVksKlKDt16hQrLWUtffTzzz9L/fr11Wvw2jFjxqhrUCD11LdvX7VM1apVTSkjy/SRLetG5IrYUiCHOHPmjLp/44031P1vv/0mH3zwgUyePFkV9Ojk7dy5sxw8eFAFizx58si6deskLCxMFd716tVTr8MZYOfOnSsdO3ZUBTzeBwX8y8ybN0+GDBmi0kqff/65REVFqQIewaRHjx7qvbAeSBlZ64uwdd2IXBGDAiUpFKA4Y6sGBe/evXtVoVuyZElTiwFncEXns3YZ0R07dsi2bdskPDxcateurR5DvwAuN4rTgtepU0fu378vP/zwg2pZdOnSxbQMLiiE11qDgDNx4kSpVq2aDB061PQ43nflypWSOnVqyZ49u3qsUKFCki1bNqt9Dq9at2TJeGiRa+KeS0lq3759UqRIEd1jnp6eUq5cOVVb1zqZc+fOrbuu9K5du9RzSM+YBxWkcVasWCEnTpyQf/75R3VcV65cWff+tWrVijMooIVy48YNqV69uu7xNm3aqJstbFk3BBQiV8SgQEkKAQEtAEBBmjJlSnXJUMuRPH5+frq/b926pVoZpUqVsvq+aA3ginIQEBCgey5jxoxxrg/eF9KnTx/Pb2TbujEokKtiUKAkhcK+WLFidr8OaRxfX1/VX2BNjhw55PDhw+r/qPmjpWFZ8Fvj7++v7m/evKl7PDo6Wl2yFCmtxFg3IlfF0UfklIKDg1WfAWrkCCraLTIyUvUJIG2DAtzb21tWr16te+2mTZvifF8ED7QsLJdZvny5mrCGdBTSWwldNyJXxZYCOSXk6zGfAUNMccMIH7QMMLcBnbq4/jTguXHjxomPj4+ULVtWTTp7WVDw8vKSrl27qv4MpJDQD4B+Brxv8+bNJU2aNKbWBEYUVaxYUX12fNaNyBUxKJBTQm192rRpMn78eJk6dapKEQUGBqqRRhgOqgkNDVWpnDlz5qgbWg9ffvmlDBo0KM73RuGP1+C61QsXLlQT29q1a6du8Pbbb6uOcAxtRacy1iM+60bkiniNZiIrkBp69uwZh5aS4bBPgciKZcuWqZFT2kn1iIyCQYHICsx9yJkzp+rIJjISBgUiK44fP67Ow5QhQwZuHzIU9ikQxdGnkNSn9CZyRmwpEFnBgEBGxaBAREQmDApERGTCoEBERCYMCkREZMKgQEREJgwKRERkwqBAREQmDApERCSa/wOJmfwODlibrgAAAABJRU5ErkJggg==",
      "text/plain": [
       "<Figure size 400x300 with 2 Axes>"
      ]
     },
     "metadata": {},
     "output_type": "display_data"
    },
    {
     "name": "stdout",
     "output_type": "stream",
     "text": [
      "-- Evaluare model: Random Forest --\n",
      "Matrice confuzie:\n",
      "[[1900   32]\n",
      " [   3   65]]\n",
      "Recall (Sensibilitate): 0.9559\n",
      "Specificitate: 0.9834\n",
      "F1-score: 0.7879\n",
      "ROC-AUC: 0.9874\n"
     ]
    },
    {
     "data": {
      "image/png": "iVBORw0KGgoAAAANSUhEUgAAAYUAAAFACAYAAABTBmBPAAAAOnRFWHRTb2Z0d2FyZQBNYXRwbG90bGliIHZlcnNpb24zLjEwLjgsIGh0dHBzOi8vbWF0cGxvdGxpYi5vcmcvwVt1zgAAAAlwSFlzAAAPYQAAD2EBqD+naQAANItJREFUeJzt3Qd4FFXbBuA3IZRQooBAkBZq6ASQEiR0qQFpFoQofPQO0gVBioq0QOidgEE6GOlFPjpIEVAgBAUhSA+9l+x/PYd/9tsJG8imbXbnubn2WnZmdjI7O3veOe85Z8bFZDKZhIiISERcuReIiEjDoEBERGYMCkREZMagQEREZgwKRERkxqBARERmDApERGTGoEBERGYMCgmA4/+I7IO/vYRniKAQEBAg3t7e8umnn8a4TO/evdUyAwcOtGndhw8flg4dOrxxucmTJ6v1O5MrV65Iy5YtpUSJEuLr6yuPHj1KkPXiO6hRo4Yk9fFh+ShcuLCUKVNGmjZtKj///LMkJfx9HC/2En1fWD5Kly4tyUVsf3tkGzcxCFdXVzl69KgqyDw9PXXzHj58KNu3b4/TepcvXy5///33G5f76KOPxM/PT5xJcHCw2qdjx46VbNmyibu7e4Kst0uXLvL5559LUipatKgMGzbM/PrFixfqWFmwYIH0799f3n77balataoYRfPmzdUxa+13lFzE9rdHtjFMUMCP/q+//pKNGzdK69atdfMQEFCgeXh4JNrfRyCKHowc3e3btyVr1qxSv379BF1v7ty5JamlT59efHx8XplepUoVVQtatWqVoYICjlVr+4OcX/IJ+4ksbdq06keNoBDd+vXrpU6dOuLmpo+RN2/elOHDh0v16tWlePHiUr58eenatatcvHjRnOZYvXq1/Pvvv6pqjYID8/D/+fPnS926daVUqVKycuVKq+mjNWvWSJMmTdQy1apVk/Hjx8vTp0/N88PDw6Vjx44qjYEH/nZERMQbP+uOHTtUqgw/6sqVK8vQoUPl7t275vn//POP9OjRQ95//321DNInqIprtM+wYcMGtRxSBvjsQ4YMUbUqQHoHn/fSpUvmdAde4//a/tFgWS0tpy1j7aEtYy19hLPCBg0aqO8B+wp/D2fziS116tSSKlUqcXFxifVxAdingwcPllmzZqntRYoN38nx48d16//tt9/kk08+UccAjsG9e/e+sg337t2T77//XmrVqqXW4+/vLytWrNAtg/01ZcoU+e6776RChQrqO+vTp488ePBAbQOCW9myZaV79+5y69atBNk3sd0ubNMXX3whJUuWVPtEO6HAcVmpUiX13o8//lj27dune++ePXvUdHyWcuXKSefOnc01A2u/PUoYhqkpAM5oe/XqpUsh3b9/X3bu3KkKcTxbNmChQL5z54707dtX3nnnHTl9+rRMnDhRpRnmzp2r0hwoIE6ePKl+kDjD1QpNFFr4AeAMFD94FGqWQkJCZMSIEaqK/uWXX6rCfsyYMervYfq5c+dUIZIvXz754Ycf5Pnz5zJ9+nRp0aKFynFnzpzZ6mdErQc/npo1a6ptxY8P68WPB9uM2hJ+aF5eXqqQT5kypSxcuFD9aOfNm6cKOA0+Z7NmzWTatGmqMAsMDJSMGTOqwgafF+vXPjv2p7UCLToUkEuXLtVNw77funWrCpDWzJw5U/3tVq1ayaBBg+TUqVNq/16+fFkVOAkB3zf2sQYBB/ts6tSpqmD98MMPY31caDZt2iT58+dX+xnvw/eIQvnXX3+VFClSyIkTJ+Q///mPVKxYUYKCglRQwbFg6fHjx/LZZ59JZGSkCtA5cuRQ+wrH1o0bN6RTp07mZfH9IdBjX/3555/qJAN/A7W5kSNHqvV/++23apstU2XWREVF6faHRjtxsmW7cKy3adNG2rdvL+nSpZMnT56o4w3LoS0P24cTp3bt2smcOXNUzQy/B/y+cPxhn+CkZsKECaoNYcuWLVZ/e5RATAbQqlUr9Xj06JHJx8fHNH/+fPO8VatWmapWrWqKiooyVa9e3TRgwAA1/cqVK6aAgADTwYMHdesaOXKkqXjx4ubXWB7v00RERJgKFSpk+uqrr3TvCwoKUtPhxYsXJl9fX1OXLl10y8yZM8fUpEkT09OnT01ffvmlqVKlSqZ79+6Z59+6dctUtmxZ0+jRo2P8rHh/48aN1efRrFu3zlS7dm3T9evXTT179jRVqFBBt95nz56Z6tSpY2rWrJnuM/Tt21e3buwPf3//GD/7ypUr1fvwfkuW+zW6zZs3m7y9vU3BwcFW13v37l1TyZIlTUOHDtW9b9myZepvhYeHm+ILxwbWFf2B7WrYsKFpw4YN5mVje1xgnaVKldLt59WrV6v1/vHHH+p19+7dTVWqVFHft+V3hWVwvEBISIh6feTIEd3fw/FVokQJdUwA9pefn5/6LjV169Y1lS5dWu1DTceOHU2NGjV67f6wti+0x7Vr12zerlq1aumWWbp0qXrv0aNHzdNwvLZs2dLUtGlT9Xrt2rVqGexvzbFjx0wTJkww79Poxx8lDEPVFNKkSaOqs5btCuvWrZN69erp0gOAhlOcQeMMD2dY58+fl7Nnz8qRI0d0KZ6YFClSJMZ5qAXgDOuDDz7QTW/btq16wP79+9VZO7ZZO2NDreO9996L8YwcZ284c8LZqOXnQQ1Jy/sjXYG0B9ZlefaH1Ix2VqyJnlNGbQBnzwklLCxMNeI2btw4xobl33//XX0ufG+WZ65aegkphoIFC1o908VDg/2Bs/OYFCtWTKWE4Nq1a+rM/9mzZ+oZtbW4HBcFChTQ7We8F7ReWkjZ4btAbU1Tu3Zt3Xbi+8JZePReP40aNVKpmmPHjpnbOpCesUyBokaAtGmGDBnM09BgjrTkm6A2iUd0qCnaul3RfwtIE2XJkkXtc8vvFPtCqy2jdo3UHRq8kYZF+gtpMXxGSlyGCgqAANCtWzeVQsJBhwMUKSVrQkNDVZUVaQr8mHBwo5CODfwYY4KUDsSUAtKWQVsHHtFlypTJ6nvwY0Jh9br1YhkUFtFhGt6LdJomem8i9DxJqH7hCIpIc6HA1Qrj1+2rmLoeogC35quvvlI5Zw0KMKRtYoK0BnLbGhRKKOCQ3kG+2nKfx/a4sLb/QAtW+C60QlaDQt1yGpZBARqd9h1athVZBqDYHIevg5SO5f6Izpbtir4N+E6vX7+ugoI1mIeA+uOPP6r2EAQZBGJ0BEHKCr/X6CdxlHAMFxRwxoECALUFHKw5c+ZUjYXRHTp0SAYMGKAaDHH2rp3l4UzGslE2LrReTsiJWkIDIM70cfaFszs0wiEXG130BnHLQgE/lujrRQ4XNQ8UdG+99ZbK5Vr7IQIKpJgK2jfRfqiWZ+hgWfsAnFGjYRbbhdoJgvOb9tW4ceNUO0h01gIcIPBjDIUGjcW2wHrRENqzZ0+Vh0d+PqGPCwSU6N8Fgi4KXA2+L9RGXvd92UN8tgvHNr5LfKfW4DcJqBWgvQDHC/Yt2qJmzJihxpDg5I4Sh2F6H1kWDugtgUZA9K5B2iSmtAUKN6RitB8+Gh+11I1W8MWl3zbOjvGjiT42Ag3IOCNG2gKpIzQK4ywUZ2x4IHih3zwa2qxBsMPy0deLBnSsF4U9enFgvmWNAJ8LaTT8DVsLT0vamSpqYRr0FtHO9jVo5ERDKBpX39RNF4EM6ZWrV6+a9wMeCIw4W4/e08myYLFcPi4DB5G2wNiStWvXqnSJLcdFbKBBFd+N5aC/Xbt2qe9fg+8LKTv8XUuorWC/2CudEp/twrGNWhZqtJbfEVKBaGhG+gzHOdJJCAg4JrGv0FgO6PGW3MZMOBPD1RQA+XX0IMFBhZ4h1mgHNXoCoQcEzt7QiwJ5cEAvIxSCOJPF2R66gb6uHcESDnoUKlg3fhjIj6OdAYUkzm5xFobeFeh9hO1EjyOcTeNMCT08sFxM0BMEaRn02ECuHtuGwhOBsFChQuoMGgURcvgIFPgBo5qO3h74QcYHcr5Io4wePVqdYaOGgG3FGbEGP3akY5CWQXoFg980+PFjPIklBE/0Spk0aZIKZPgbCBB4jZoJzhoTE9JQSCONGjVKpaNie1zEBmpL+D5R48BnRA0PbRiWbQwYUb148WK1LL5bBDukwdBbB99lYo6teZ34bBfei2MOtWD0UsqePbsKqrNnz1Y9zPD50SMLNQmsH9Pwm1myZIk6RhAsIPpvDykvij9DhlqkZXBAoYESXQatQeGD9AHOhNCVDgXdu+++q6qzoKUKcIAjX42DF+MOYguFP9Z54MABVfCjsMTfQcMroLBDYYOCD9Pww0PVHOkWNEbGBD8YVLEvXLigtgmFZ8OGDdWoY8Bnxo8ZwQjdO/v166dSFsjZYr/EB/apNn5A+9t4tkzPbdu2zdx9EvsOffS1BwoTa5BDRr901JCwj/BZ0OceBYtlI2piQK0OqSJ0O/3pp59ifVzEBlIo+Awo8NA1E11/kZrCSYEGgXPRokXqe8X+RMDH30BKCycW9hKf7ULaFsc2vkN8l9iPmzdvVl2dcUxqxz+OY5wI4AQHxwZqnDhutIb/uP726PVc0AXpDcsQEZFBGLKmQERE1jEoEBGRGYMCERGZMSgQEZEZgwIREZkxKBARkRmDAhERGW9Es3tp6wOjyDlFHrDfPY4p6aVN5ZJkZcOj318OVHRWhgkKRERWuTBhYolBgYiMjZfh1mFQICJjY01Bh0GBiIyNNQUdBgUiMjbWFHQYFIjI2Fxjvne3ETEoEJGxMX2kw6BARMbG9JEOgwIRGRtrCjoMCkRkbKwp6DAoEJGxsaagw6BARMbGmoIOgwIRGRuDgg6DAhEZm2vcr7DqjBgUiMjYOHhNh0GBiIyN6SMdBgUiMjb2PtJhUCAiY2NNQYdBgYiMjTUFHQYFIjI21hR0GBSIyNhYU9BhUCAiY2NNQYdBgYiMjTUFHQYFIjI2VxaDlrg3iMjYWFPQYVAgImNjm4IOgwIRGRtrCjoMCkRkbKwp6DAoEJGxsaagw6BARIbmwqCgw6BARIbGoKDHoEBExsYbr+kwKBCRobm6utp7E5IVBgUiMjSmj/QYFIjI0BgU9BgUiMjY2Kagw6BARIbGmoIegwIRGRqDgh6DAhEZGoOCHoMCERkag4IegwIRGRsbmnUYFIjI0FhT0GNQICJD44hmPY7vJiJjc7HxkUBmzpwpAQEBumlDhgwRb29v3aNGjRrm+VFRURIUFCR+fn7i4+Mj7du3l4iICN06Tp06Ja1atVLz8d6FCxfatF0MCkQkRk8f2fJICCEhITJx4sRXpp8+fVo6deoku3fvNj9WrFhhnj9t2jRZvHixjBw5UpYsWaKCRLt27eTp06dq/q1bt6RNmzaSO3duWblypXTt2lXGjRun/h9bTB8RkaElZZvC1atXZdiwYXLgwAHx8vLSzTOZTPLXX39Jhw4dJEuWLK+8FwX/vHnzpG/fvlKtWjU1LTAwUNUaNm/eLP7+/rJs2TJJmTKljBgxQtzc3CR//vxy/vx5mTVrljRr1ixW28iaAhEZWlLWFE6cOKEK7dDQUClVqpRu3oULF+Thw4eSL18+q+8NCwuTBw8eiK+vr3mah4eHFC1aVA4ePKheHzp0SMqXL68CgqZixYryzz//yI0bN2K1jawpEJGh2VrQ16xZ87Xzt23bFuM85Pgt2wgshYeHq+dFixbJzp07VQN4lSpVpHfv3pIhQwa5cuWKmp89e3bd+7JmzWqeh+dChQq9Mh8uX74s77zzzhs/H4MCERlbMhmnEB4ergIBCvEZM2aomsOYMWPkzJkzEhwcLI8ePVLLpUqVSve+1KlTy507d9T/Hz9+bHU+PHnyJFbbwaBARIZma01h22tqAvHRuXNn+eyzzyRjxozqNc740bbw8ccfyx9//CFp0qQxty1o/9cKe3d3d/V/TNcanS3nQ9q0aWO1HWxTcBA5sr4tl3eOEb+yBXXT6/kVl12L+sqt/YHy18aRMqZPU0nnrj9TSJHCVYZ2aSBnNoyUyL0TZOvcXlKueJ5X/sbHdcvK4RWD5ea+CfL7yiHSsmGFRP9cZBv0Nlm4YK40alBHKr5XSj5u9qGsX/uLbpktmzZKy0+by/sVykjdWtVk2JBBEhnLfLIR2aP3kTWoJWgBQVOwYEFzWkhLG127dk23DF5ny5ZN/d/T09PqfNCWeRMGBQeQM9vb8sv0rvJ2Bn2kb1S9pKyY2EHuP3wirQbMk37jVkrV8oVkw8weKhBoECh6tKohE4K3SsDAefL8RZSsm9Fd8uX6X36xcU0fmf/tF7Jt3yn5+MvZsvPwGZkzIkA+qlM2ST8rvd70KUEyedJEadykmUyaMkMqVPSVwYP6yYb1a9X8jRvWSf++vaRI0WIyLjBIuvboJb/9dkA6tGsd6/SB0bi4utj0SCz9+/eX1q1b66ahhgAFChSQwoULS/r06VXPJc3du3fl5MmTUq5cOfUaz4cPH5YXL16Yl9m/f7/kzZtXMmfOHKvtYPooGcNZSUv/8vJ97yZWz1AGd6ovYeeuSqOu0+TZ85cHwZ4jf8uJX76RzxtVlPmr96qA0r65n/QZu1xmL9+tltm6L0z++Hmo9Gn9gXQd+ZOaNrxbQ1m15XfpP37V/y9zSjJ5pFU1jOWbDifp5ybrkFMO+XGhfNYqQP7TroOahqBw6uQJ+SlkkdSr7y/zZs+Uyn5VZcjQ4eb3eXnllc9bfiI7d2yXD2rX5e5Nppe5qFOnjnTp0kWmTJkijRo1knPnzqmupehqiq6lgEFpGHeQKVMmyZEjh4wdO1bVDmrXrq3mo9vpnDlzZPDgwWr8wvHjx2XBggUyfPj/joc3YVBIxkoUfFcmD/5UZi3fJb8eCJM1k7vo5hfO6ykzlu40BwS4dvOenD53Rer5FVNBoVp5b0mZMoWE/nrMvMzTZ89l/c4/VU0DcmfPJIW8ssmoGet161+99ag0r1NW8ufOIn9fuJ7on5deDw2ICxb9JJkyZ9JNRxfH+/fvq9RSBd9KUqbsy7NGjVfel10cL0Yb+UrJKyjUrFlTDWjDmILZs2erHkcNGzaUXr16mZfp0aOHPH/+XI18RqMyagZz585VxwCgNoCg8O2330qTJk1UmwRqIPi/QwQFfDgMukAfW3SXQgMJGkyQ+8KHRfRLkSKFGFXElVtSvNFw+ffa7VfaEiDy9gNVoFtyc3OVnJ4ZJVVKN3PguHv/kVyNvKdb7mzEdXk369uq/aFwPk817cz5q7pl/o54GQgK5cnGoJAM4LdQyNvbPNDpZmSk/LxmlRzYv0/VDJCT7tNv4Cvv2/7rVvWcv0CBJN9mR2CvoDB69OhXptWrV089XncM9OvXTz1iUrJkSVm6dGmct8tubQoXL16UBg0ayFdffaWGdqPVHFENEQ+DNAYNGqSi5KVLl8Sobt19qAJCTILX7FNtAX1a15J3MqaXXJ4ZZcawlvJWendzY7NHBne59+DxK++99/DlNI/07mp5uBttOfMy6f7X04GSB7Qd1KpeWSZPmiCV/apIff9GVpeLiLgggePHiHfhIiqtRMm3oTm5sFtNAbmynDlzqut6oJoUHRpQMGgDy6HPLr1q1Mz1qmYwtIu/jOrZWKWF5q3aK2v/e1wK53vZU8H1DQcxUg5vXMZk4u5PZoqXKClz5i+SM+GnZdqUIOnaqZ16bVlonTt7Vrp0bCtuKdxk7IRJvBpoTJy/nHeMoICUES7oZC0gaMO3UUVq2bJlkm+bo3jxIkq+DgpVbQF5c74jl6/dkTv3H8mWub3k1t0HahmkjtKnffVM3yPdy9rBnfuP1XsgQ7TltBqCNp+Sj1y5cqtH2ffKSbr06WXo4IFy5PAh9RoOHTwgfXr1UH3TZ80NVsuSdUY4+3eI9BGCAS4O9TpIHVkO0iA9tDPU8i0iT54+l7CzV1Thja6oxQq8K0dPvWxUDD9/Vd7K4K7SS5bQHfX8pUh5/OSZWgby59JfhEt7jXWT/d28eVN+CV2j2hIsFSlSVD1fv/6yPzq6p3bu0E61zQX/uETyxnAtHXqJ6aNkEhSaN28uAwcOVA0iuIqfNgoPz7g+OC71im5VTZs2tdcmJntNa/nItK9bqBSS5osPfSWjR1oJ/e9x9frX/WHquUktH/MyaISu71dcdU2FsxE35NzFG7plAO0VZ85fkwuXbybRJ6LXefLksaoRrF79v0spw769e9RzwULesmvnDvn6qwFSysdH5i1cLFljOWDJyFBRsOXh7OyWPurevbvKceLaHrgyYHTp0qVTqaOePXvaZfscwewVu6VN00oye3iABP+8T0oWyikjezRS4wp2H/5LLXPh8i1ZFLpfxvRpJu6pU6lCvker6qr2MCF4i3ld383aILNHBEjknQeybscf4l+tpOqOGjBgnh0/IVnKnv1d+bBJM5k9Y5qkdHMT78JF5fcjh2T+3NnSuGlzyZkzl3Rq30bSpk0n7dp3krN/vzwGNNmyeUo2z5c9zeh/XBNxQJojcrNnla1bt27SsWNHdacgpJIwOAfpIgzGwOi96Bd2Ir2Tf1+Wpj1myogejWTlxE5yNfKu/DBnk4yZt0m3XLdRS+T23YfyZetakj5tavn9VIT4d56iagiaH385IKlTuUmvz2uq2sa5f2/If4YEy4rNR7jbk5HBXw9Thf/KFcvk8qVL4umZXTp37SGft/6PHDr4m9y4/rIbceeObV95b8fOXaVTl+522OrkjW0Kei4mdHg2APfS3ey9CZSEIg9M5v42kLSp4n62X3ig/iTqTcJG1xFnxhHNRGRoTB/pMSgQkaEZofHYFgwKRGRobFPQY1AgIkNjTUGPQYGIDI01BT0GBSIyNAYFPQYFIjI09j7SY1AgIkNjm4IegwIRGRrTR3oMCkRkaKwp6DEoEJGhsaagx6BARIbGmoIegwIRGRprCnoMCkRkaKwp6DEoEJGhsaagx6BARIbGmoIegwIRGRpHNOsxKBCRoTF9pMegQESGxqCg5yo2mjJlily9etXqvIsXL8qIESNsXSURkV3bFGx5ODubg8LUqVNjDArHjh2T5cuXJ8R2ERElWU3Bloezi1X66NNPP1UFPphMJvnkk09iXLZEiRIJt3VERInMAOV8wgeFUaNGycaNG1VAQE2hWbNm4unpqVvG1dVVPDw8pHbt2rZtARGRHRnh7D/Bg0KBAgWkW7du5h340UcfSbZs2Wz6Q0REyRFjQjx7H2nBITIyUp4+fapqDxAVFSWPHj2SQ4cOSYsWLWxdLRGRXbgyKsQvKISFhUnfvn3l77//tjofNQkGBSJyFBy8Fs+gMGbMGLlz544MGDBAtm/fLqlSpZLq1avLzp071WPhwoW2rpKIyG5c2aQQvy6p6IXUs2dPad26tdSvX1+ljD777DOZMWOG1KpVSxYtWmTrKomI7IZdUuMZFNCO4OXlpf6PZ6STNE2bNpWjR4/aukoiIrvh4LV4BoV3331XIiIizEHh/v37aiQzIJWE1BIRkaNwsfGfs7M5KGAcwvjx42XTpk2qW2q+fPlk4sSJcvr0aZk3b57kypUrcbaUiCiR2hRseTg717h0SS1TpoysWLFCvR40aJBs2bJFGjduLPv375fu3bsnxnYSESUKtinEs/cR2hSCgoLk2bNn6rWfn5+sXbtW/vzzTylWrJjkzp3b1lUSEdkNhynEs6aAHkfr16+XlClTmqchZVSvXj0GBCJyyMFrtjycXZxqChkzZkycrSEiSmIcvBbPoPD555+rhuU0adJI4cKFxd3d3dZVEBElGwY4+U/coPDzzz/LpUuX1IC1mBptTp48aetqiYjswggpoUQNCo0aNbL1LUREyRZDQgJdJZWIyBnwfgrxDArw5MkTNVgtpktn4yqqRESOwAgD0hI8KJw5c0YKFiyo/n/gwAF1QbyYLmeRLl06BgUichj2qinMnDlTdu/erbuI6KlTp+Tbb79V474yZcqkLjyKzj0anHxPmTJFli9fLvfu3ZNy5crJ0KFDdVeSeNM6EmScQrt27eSbb75R/w8MDFRdUidNmqQueYEro+LDBQQEqFtyzp49O9Z/nIjIiBfECwkJUb04Ld26dUvatGmjxnutXLlSunbtKuPGjVP/10ybNk0WL14sI0eOlCVLlqgggfIZWZvYriNBagq4R0LdunWlS5cuKm2EezYjICBdFBwcLFWqVFEPbaMZGIjIUSRlTeHq1asybNgwlXHRrjatWbZsmRoUPGLECHFzc5P8+fPL+fPnZdasWdKsWTNV8OP6ckjPV6tWzXySjqtKbN68Wfz9/d+4jgSrKWBMAiAIIDJp92fGh8Id2DANMKoZVRciIkeRwtXFpkd8nDhxQhXaoaGhUqpUKd08tMeWL19eFeaaihUryj///CM3btxQtyl48OCB+Pr6mud7eHhI0aJF5eDBg7FaR4IFhYEDB0rJkiUlT548qlqC2oIWFNDo/Ndff6nXuB4SNpqIyFG42PiIjxo1asjkyZOtXk36ypUr4unpqZuWNWtW9Xz58mU1H7Jnz/7KMtq8N60jwdJHSBXhKqjaOAXkqJ4/fy5ffPGF+Pj4qEYN/H/OnDlSoECBWP1hIiJHHLxWs2bN187ftm1bnLbj8ePH6p40llKnTq2ecfKNTA1YW0br+POmdSRYUGjRooX5/2jUwAYcP35cvf7666+lbdu2qr0hffr0Mn369Fj9YSKi5CC5DGhOkyaNucFYoxXkadOmNafxsYz2f20Z7XJDb1pHooxTQKOM5TgEXC5769atcvbsWXXDHQQGIiJnbWjeFseawJsg7XPt2jXdNO012nGRndGmWd6iAK+9vb1jtY5EuXQ2ujjhpjra/RQAgQBtDgwIRORokss9msuVKyeHDx+WFy9emKfhxmV58+aVzJkzqwuQooxFzyXN3bt31bXm8N7YrCNRggLux4y7q1WuXFl1rTpy5IitqyAiSjaSy/0UmjVrpu55P3jwYNV5Z9WqVbJgwQLp2LGjmo+2glatWqk2XdRW0Bupd+/eqnaAdt/YrCPRrpKKbqi42xputrN06VLJmTOnaoD+8MMPVQ8lIiJHkVzaFDJnzqw666DjTpMmTSRLlizSv39/9X9Njx49VBppyJAhqlEZNYO5c+eab3oWm3W8iYtJu3hRHP3xxx8qOGzatEl1eUIaCYEiuXEvzQv5GUnkgcn23gRKQmlTxb1k77ratrFVU5sUEWcWpwviWUKDB0bNoaEDo/UuXLggydGtg1PsvQmUhJ4+fzmgkowi7kEhRXKpKjhyUHj48KHqcYQawp49e9Q1j6pWrSpBQUHqmYjIUfAqqfEMCrhC6s6dO1U+q0yZMmqcAi5vkSFDBltXRURkdwwK8QwKuMRF+/btVcMyGpiJiBwZb7ITz6CwcePGV0bLoasUdywROSLWFBKgTQGjl9F+sHfvXtUnFjd8WLFihRrRjPsqEBE5CrYzx3PwGi6N3bx5c3UJ2IYNG5pvx5kiRQr57rvvZPXq1baukohIjD54zWFrCj/88IMUL15c3exBu4MQYDAFUkm4IY8tAyWIiBzqzNjJ2bw/jh49qu75iZs4RG9HqF+/vrqZAxGRo0gu1z5y2JoCrs2N7qjW3L59+5VreRMRJWdGSAklak3h/fffV43M2p1+ADUG3HENKaVKlSrZukoiIrtJ4Wrbw9nZXFPo16+ffPLJJ1K3bl11KVcEhNGjR8u5c+dUo/OECRMSZ0uJiBIBawp6Nsc93B8UV0rF7TcRBHDtI1z2wt/fX12m1dq9R4mIkiu2KSTAOIWMGTOq63gTETk6Dl6LQ1A4ePCg2EK7CxARUXLnEo8rrBo2KGCUsrXLWFjeisFyPga4ERE5AtYU4hAUMCBNc+nSJXVlVNz2DVdHxZ190BX1119/lSVLlsiIESNis0oiomSBQSEOQaF8+fK6WgMGr/Xp00e3DC6jnSZNGpk/f74axEZE5Ah4Mc949j46fvy4+Pr6Wp1XunRpCQ8Pt3WVRER2rSnY8nB2NgcFT09P2bVrV4yX1UYXVSIiR5HC1cWmh7OzuUtqmzZt5JtvvpFr165J9erVVffUGzduqICwfft2CQwMTJwtJSJKBAYo5xM3KHz66afy/PlzmT59uqxbt043qA2jmTHSmYjIUfDSR3ouJst+pXG42c6dO3dUbcHd3V3dbGflypWqxpDcPH5u7y2gpPT0eRR3uIF4pIn7RYmm7rHtys5d3/cSZxanEc0a3GkN7Qtz5syRHTt2qBoE79tMRI6ENYUECAo3b95Ut99ctmyZ/Pvvv5I+fXp1Y50PP/xQ3nvvvbiskojILtimEI+gsH//flm6dKls3bpVXrx4IWXLllVBYerUqbqxDEREjoJXSY1DUFiwYIEKBrg8dp48eaRLly6qZpA2bVoVDDj4g4gcFdNHcQgKuF+Ct7e3utyFZY3g3r17sXk7EVGyxZqCXqya7Bs0aCDnz5+Xjh07qlrCli1bVKMyEZGjS+Fi28PZxaqmMH78eLl//7788ssv6kY63bt3V91Qa9WqpVJHTB8RkaNi+ZUA4xTOnDmjxiMgSERGRqpLW6A2gUeBAgUkOeI4BWPhOAVjic84hYWHImxa/vP3nPvukvEavIYUEgaqIUDs3r1b9UgqWLCghIaGSnLDoGAsDArGEp+g8OPhizYt36psTnFm8Rq85ubmJh988IF64PpHq1evVg8iIkdhgGaCpKspOBLWFIyFNQVjiU9NYfER22oKn5VhTYGIyGmxoTkB00dERI4u7nUM58SgQESGxpqCHoMCERkaRzTrMSgQkaExfaTHoEBEhsb0kR6DAhEZGscp6DEoEJGh8dLZegwKRGRorqwr6DAoEJGhsaagx6BARIbmwpqCDoMCERkaawp6DApEZGhsU9BjUCAiQ3Pl6DUdBgUiMjS2KegxRhKRobm62PaIj6tXr4q3t/crj1WrVqn5p06dklatWomPj4/UqFFDFi5cqHt/VFSUBAUFiZ+fn1qmffv2EhFh2+1E34Q1BSeEA2dR8HxZsWypXL16RfLk8ZLWbdtJA/9G9t40SgB/HD8qUycFyok//5C0adOK7/uVpUfvfpIpc2Y1v90XLeXY0SOvvC948XIpWqw4vwM71hTCwsIkderUsnXrVt3lNTJkyCC3bt2SNm3aqGAwfPhwOXr0qHpOly6dNGvWTC03bdo0Wbx4sYwePVo8PT1l7Nix0q5dO/nll18kVapUCbKNDApOaNrkSTJ/3lzp0q2HFC9RQnbt3CFfDegnri6uUq+Bv703j+Lh1MkT0rldaylXwVfGBk6W69evydSgCXLhwnmZt/AnwY0U/zpzWj4LaC21atfRvTdv3nzc93bufRQeHi5eXl6SNWvWV+YFBwdLypQpZcSIEepWx/nz55fz58/LrFmzVFB4+vSpzJs3T/r27SvVqlVT7wkMDFS1hs2bN4u/f8L8thkUnMyjR4/kx0ULpWVAgLRt30FNq1DRVxUmi0MWMSg4uKDAcVKocBEZP2mquP5/CynOJMeP+V7+vXhRoqJeyIMHD+R9vypSoqSPvTfXISRlTeH06dOqsLfm0KFDUr58eRUQNBUrVpSZM2fKjRs35NKlS+q79fX1Nc/38PCQokWLysGDBxkUyDpUIReG/CSZMr1MJWjcUqaUe/fucbc5sNu3b8mRQ7/JsJHfmwMC1KhVWz1g25ZN6rmQd2G7baejiW87ga01hYwZM0rLli3l3LlzkidPHuncubNUqVJFrly5IoUKFdItr9UoLl++rOZD9uzZX1lGm5cQWFNwMilSpDAXCEgl3IyMlDWrV8mBfXvl62Ej7L15FA9/hYer9qKMGTPJkEH9ZNd/fxWTSaR6zVrSd8BgyeDhIeGnT6l2hknjx8qundvl0cOH8l75CtK73yDx8srL/Z8ANYWaNWu+dv62bdusTn/+/LmcPXtWChQoIAMHDpT06dPLunXrpEOHDjJ//nx5/PjxK+0CaH+AJ0+eqCwAWFvmzp07CfbdMig4sY3r18nA/n3U//2qVpMGDdnQ7Mhu3bqpnkcOGyyVKvvJ2IlTJOL8eZkaFKhSR7MX/CjhYWHy8OFDlVZAm8PlS5dkzsyp0qF1KwlZtlqyWMllG11StSm4ubnJgQMH1IlbmjRp1LTixYvLmTNnZO7cuWoa2g0sIRgAAr32Hiyj/V9bxt3dPeG2M8HWRMlO8RIlZV7wjxJ++rRMnTJJunRsJ3MXLOJNRRzUs2fP1HPhosVkyDej1P/LV/BVPVcGD+yraoOdu/eSgDZtpUzZcmp+6TIiJX1Ky8eNG8iSkIXSvXdfu36G5CiFjVFhWww1gdhA+090BQsWlN27d6veRNeuXdPN015ny5ZN1TS0ablz59Ytg26tCYXjFJxYrty5pex75aRFy1YyYOBgOXzooBw5fMjem0XxLFAqV3nZ80Tj+76fej4ddlKlDrWAoMmZM5d45csv4eGnue+tcLHxEVeoEZQpU0bVFiz9+eefKqVUrlw5OXz4sLx48cI8b//+/ZI3b17JnDmzFC5cWKWcLN9/9+5dOXnypHqvU9QUAgICYn3WGn0QB1l38+ZN2bNrp0ov4EDSFC5aVD1HPxMhx5Erdx71/CxaikE7g0ydOo2sDV0jufPkkZKlSuuWefL4sWrgJCuSKH2UP39+yZcvn+pyivEH+D6WLVumxiOsXLlS/V7nzJkjgwcPVmMPjh8/LgsWLFDLam0JGNg2btw4yZQpk+TIkUONU0ANo3btlx0NHL6mULlyZdUNKzIyUn3A1z0odvDjH/LVAFmzaoVu+r49e9RzoUIJV82kpJU3X355990csnnTetWJQLPzv7+q59JlysrsGVMlaMI43fvCTp2QixEX5L1yFfiVxdDQbMu/uEKPsRkzZkjJkiWlV69e0qRJEzl27JhqZEavIy0ooFcS5k2ZMkX69++v/q/p0aOHNG/eXIYMGSItWrRQ7RNoj8D4hoTiYrI8uuwgJCRExo8fL6GhoZIzZ85E+zuPX55MGcKwr7+SDevWStfuPaVwkaIqZTRvzizV0PzNiG/FCJ4+jxJnhC6ng/r1lpof1JHGzT6Sc3//LdOnTJSKlSrLD+Mnybpf1sg3QwZJff9G6nH58iWZOW2yvPNOFlkQskwVIs7II03cz29/O2tbz53y+d4SZ2b3oACdOnVSVSNc0yOxGCkoIL2wYP5cCf15jVy+9K94emaXZh99LF+0aavr3+7MnDUowK4d22XOzOlq5LLHW29J3foNpXO3nuauils2bZBFC+bKubNnVa+UajVqSdeeveWtt94WZxWfoHDQxqBQjkEh8SHPfeLECalevXqi/Q0jBQVy7qBACRwUztkYFPI6d00hWXRJxYg8a9cCISJKbLx0djIMCkRE9sLbceoxKBCRoTEo6DEoEJGhMX2kx6BARIbGmoIegwIRGVoSXjnbITAoEJGxMSroMCgQkaGxTUGPQYGIDI1tCnoMCkRkaMwe6TEoEJGxMSroMCgQkaG5Mn+kw6BARIbGioIegwIRGRujgg6DAhEZGruk6jEoEJGhsUlBj0GBiAyN2SM9BgUiMjZGBR0GBSIyNLYp6DEoEJGhsU1Bj0GBiAyN2SM9BgUiMjQXVhV0GBSIyNAYE/QYFIjI0Jg+0mNQICJjY1TQYVAgIkNjl1Q9BgUiMjS2KegxKBCRoTF7pMegQESGxpqCHoMCERkc6wqWGBSIyNBcGRN0GBSIyNCYPtJjUCAiQ2OXVD0GBSIyNqaPdBgUiMjQGBP0GBSIyNDYpqDHoEBEhsY2BT0GBSIyNuaPdBgUiMjQGBP0GBSIyNBc2aigw6BARIbGmKDnGu01EREZGGsKRGRorCnoMSgQkaGxS6oegwIRGRprCnoMCkRkaOySqsegQETGxqigw6BARIbGNgU9BgUiMjTeeU2PQYGIjI3pIx0GBSIyNKaP9BgUiMjQ2CVVz8VkMpmiTSMiIoPitY+IiMiMQYGIiMwYFIiIyIxBgYiIzBgUiIjIjEGBiIjMGBSIiMiMQYGIiMwYFIiIyIxBgYiIzBgUiIjIjEGBiIjMGBSIiMiMQcEJRUVFSVBQkPj5+YmPj4+0b99eIiIi7L1ZlARmzpwpAQEB3NcUZwwKTmjatGmyePFiGTlypCxZskQFiXbt2snTp0/tvWmUiEJCQmTixIncxxQvDApOBgX/vHnzpEePHlKtWjUpXLiwBAYGypUrV2Tz5s323jxKBFevXpVOnTrJuHHjxMvLi/uY4oVBwcmEhYXJgwcPxNfX1zzNw8NDihYtKgcPHrTrtlHiOHHihKRMmVJCQ0OlVKlS3M0UL7wdp5NBjQCyZ8+um541a1bzPHIuNWrUUA+ihMCagpN59OiRek6VKpVueurUqeXJkyd22ioichQMCk4mTZo06jl6ozICgru7u522iogcBYOCk9HSRteuXdNNx+ts2bLZaauIyFEwKDgZ9DZKnz69HDhwwDzt7t27cvLkSSlXrpxdt42Ikj82NDsZtCW0atVKdU/MlCmT5MiRQ8aOHSuenp5Su3Zte28eESVzDApOCGMUnj9/LkOGDJHHjx+rGsLcuXNVt0UiotdxMZlMptcuQUREhsE2BSIiMmNQICIiMwYFIiIyY1AgIiIzBgUiIjJjUCAiIjMGBaIYsLc2GRGDAiUa3BbS29tb9yhevLi6+c/w4cPlzp07ifJ3V61apf7WxYsX1evJkyer17GFS4x36NBB/v33X/M0XJp64MCBibK9RMkJRzRTosLNfYYNG2Z+/ezZM3VTmAkTJsipU6fkp59+EhcXl0Tdho8++kjdrzq29u7dKzt27NBNmzJlirqmFJGzY1CgRIWC1MfHRzcNl93A3eGCgoLk2LFjr8xPaLjuEx7xDW5ERsD0EdkF0khw6dIllWbq27evumYTAkSbNm3M94AYM2aMVK1aVS3fsGFDWb9+vW49UVFRMm3aNJWSwq0ou3Tp8kpaylr6aM2aNdKkSRP1Hrx3/Pjx6h4USD0NGjRILVOzZk1zyih6+ig220bkiFhTILs4d+6ces6VK5d63rBhgzRq1EimT5+uCno08nbt2lWOHDmigkX+/Plly5Yt0rt3b1V4N27cWL0PV4BduHChdO7cWRXwWA8K+NcJCQmRESNGqLTSl19+KREREaqARzDp1auXWhe2Aykja20Rsd02IkfEoECJCgUortiqQcH722+/qUK3dOnS5hoDruCKxmftNqJ79uyRXbt2SWBgoNSvX19NQ7sAbjeKy4L7+/vLw4cPZdGiRapm0a1bN/MyuKEQ3msNAs7UqVOlVq1aMmrUKPN0rHfdunWSIUMGyZ07t5pWpEgRyZkzp9U2hzdtm5sbf1rkmHjkUqI6ePCgFCtWTDfN1dVVKlWqpM7WtUbmfPny6e4rvW/fPjUP6RnLoII0TmhoqJw5c0auX7+uGq6rV6+uW3+9evViDAqooURGRsoHH3ygm962bVv1iI3YbBsCCpEjYlCgRIWAgBoAoCBNnTq1umVo9J486dKl072+ffu2qmWUKVPG6npRG8Ad5SBjxoy6eVmyZIlxe7BeyJw5cxw/Uey2jUGBHBWDAiUqFPYlSpSw+X1I46RNm1a1F1iTJ08eOX78uPo/zvxR04he8Fvj4eGhnm/evKmbfuvWLXXLUqS0EmLbiBwVex9RslS+fHnVZoAzcgQV7REeHq7aBJC2QQGeJk0a2bhxo+6927dvj3G9CB6oWURf5ueff1YD1pCOQnorvttG5KhYU6BkCfl6jGdAF1M80MMHNQOMbUCjLu4/DZg3ceJEcXd3l4oVK6pBZ68LCilSpJDu3bur9gykkNAOgHYGrLdly5by1ltvmWsT6FFUpUoV9bfjsm1EjohBgZIlnK3PmjVLJk2aJDNnzlQpomzZsqmeRugOqunYsaNK5QQHB6sHag8DBgyQb775JsZ1o/DHe3Df6qVLl6qBbe3bt1cPqFChgmoIR9dWNCpjO+KybUSOiPdoJrICqaEXL16waykZDtsUiKxYvXq16jmlXVSPyCgYFIiswNgHLy8v1ZBNZCQMCkRWhIWFqeswvfPOO9w/ZChsUyCKoU0hsS/pTZQcsaZAZAUDAhkVgwIREZkxKBARkRmDAhERmTEoEBGRGYMCERGZMSgQEZEZgwIREZkxKBARkWj+DxDdI4qwnQn4AAAAAElFTkSuQmCC",
      "text/plain": [
       "<Figure size 400x300 with 2 Axes>"
      ]
     },
     "metadata": {},
     "output_type": "display_data"
    },
    {
     "name": "stdout",
     "output_type": "stream",
     "text": [
      "-- Evaluare model: XGBoost --\n",
      "Matrice confuzie:\n",
      "[[1912   20]\n",
      " [   3   65]]\n",
      "Recall (Sensibilitate): 0.9559\n",
      "Specificitate: 0.9896\n",
      "F1-score: 0.8497\n",
      "ROC-AUC: 0.9939\n"
     ]
    },
    {
     "data": {
      "image/png": "iVBORw0KGgoAAAANSUhEUgAAAYUAAAFACAYAAABTBmBPAAAAOnRFWHRTb2Z0d2FyZQBNYXRwbG90bGliIHZlcnNpb24zLjEwLjgsIGh0dHBzOi8vbWF0cGxvdGxpYi5vcmcvwVt1zgAAAAlwSFlzAAAPYQAAD2EBqD+naQAANFBJREFUeJzt3Qd4FNXXBvBDaKEFkS69dwgtEJr0DlIEpEnvTZRepCvSCRCkShEEpBnpRaSDAUSkJkjvEnonZL/nvf5nvp1kA9kUdjfz/nzWkJnZ2dnZzT1zzr0zE8disViEiIhIRNy4F4iISMOgQEREOgYFIiLSMSgQEZGOQYGIiHQMCkREpGNQICIiHYMCERHpGBRcBM8xJFfF765rYVCIJq1bt5Y8efLIZ599Fu4yffv2VcsMGjTIrnUfPXpUOnfu/M7lZsyYodYfm9y6dUtatmwphQoVEm9vb3n+/Hm0rBefQeXKleV9uHPnjpQqVUrq1asnr169CjN/6dKlkjdvXtm9e3eY9z5p0iSpW7euFC1aVD0aNmwoc+fODbMftO+f9aNEiRLy+eefyx9//CGO8vPPP8t3333nsNcn+8WLxHMoHG5ubnL8+HH1x5wuXTrDvGfPnsmuXbsi/Yf1zz//vHO5Jk2aSPny5WPV57N48WK1TydOnChp06aVRIkSRct6u3fvrhrM9yFNmjQyZswY6dWrl0ydOlUGDhyoz/v7779Vo9muXTv5+OOP9emHDx+W3r17S/LkyaVFixaqkQ8JCVHTZ8+eLdu2bZNly5ZJwoQJ9efkz59fRowYof795s0buX//vvz000/SoUMHWbt2reTKlUveN2yrl5fXe39dijwGhWiEP8rz58/Lli1bpG3btoZ5CAho0Dw8PCSmIBCFDkau7sGDB6pRrV27drSuN3PmzPI+Va9eXRo1aiQ//PCDavxLly4tjx49ki+++EJlCV9++aW+7L1791RWmTVrVrV84sSJ9Xlly5aVKlWqSPPmzVXAtM4gkyZNKp6enobXLVOmjMqwEBSsgxFReFg+ikb448UfPIJCaJs2bZIaNWpIvHjGOIwGYNSoUVKpUiUpWLCgOqrq0aOHXLt2TS9zrFu3Tq5fv66OFvHHjXn4NxqMmjVrSpEiRWTNmjU2y0fr169XJQcsU7FiRZk8ebKhhBEQECBdunSRYsWKqQde++rVq+98ryh1oFSGRqhcuXLy9ddfq0ZOc+nSJXWki0YMy6C8gTKYRnsPmzdvVsuhNIL3PmzYMJVVAco7eL83btxQy+L94Xf8W9s/GiyrleW0ZWw9tGVslY+QkdWpU0d9DthXeD0ccUcXvLeMGTOq1378+LEMHz5cHj58qLKH+PHj68stX75cgoKCZOzYsYaAoMFn2aZNG5vzQsOBCLKJOHHihPk+Ikhhv+MzwueHbbGGLAZZBkpf+G507dpVAgMDDcsgMOE7iPIestSRI0fKkydP1DzsX3xv8f219ZmRk8JVUinqWrVqpR6bN2+25MmTx3Lz5k193uPHjy0FCxa0+Pv7WypVqmQZOHCgmh4SEmL59NNPLdWqVbNs2LDBcujQIcvixYstRYsWtbRv314tc/nyZUunTp0sZcuWtfz555+WoKAgy9WrVy25c+dWy61evdqyZcsW9Xo+Pj5quubHH39Uvw8dOtSyZ88ey7JlyyxFihSxDB8+XM2/cOGCWkfjxo0t27Zts2zatMlSr1499Vp3794N973+9ttv6j12797dsmvXLsu6dess3t7e+jYHBgaq9TZs2FCtc/v27ZbWrVtbChQoYDl8+LBaRnsPJUuWtIwfP95y4MABy/fff6/WO2nSJLXMqVOnDO8d73HNmjXqeXi+Nev9in2E5a0fvXv3tuTPn1/tY8CyeI5Ge+0xY8ZY9u7da5k7d66lUKFClsGDB1ui07Fjxyz58uWzNGjQQL0P7J/QMA+fgz3w3WvZsqXl9evX6vHq1SvLnTt3LBMnTlSf+fnz5/VlZ82apd7rqFGj9O+Fl5eXes3nz5+rZQ4ePKg+L3ymO3bssGzcuNFSv359S7FixfR1/frrr2qZJUuWqM/1p59+snh6eloGDBigf3747PAZ4jN4+fJlFPcevQ8sH0UzHGHi6My6hLR9+3ZJmTKlFC9ePEwHJJZFWo9OQcBR2ZUrV2TlypV6mePDDz+UBAkS6KUB7Ui6Vq1a0rhxY5vbgfrzrFmzpGrVquqIU4MOyo0bN8rr169l5syZ6vUXLVqkSg+AUgOeM3/+/HDLDTiCzpcvn3q+dgSK7Zs+fbrcvXtXTcfvS5Ys0deL/YIO0wkTJsjq1av1dSGz0l4Hr71//375/fff5auvvlLluNDvPSLwHDw02P9bt26VIUOGqP0bGo7afX19pVmzZupoHpD9fPDBB+p31Pujqx6PI3P0ZSDLw37GZxgaPn8cvYcWHBwcZpp15unv7y8FChQIswxKUzly5FD/RjaAOn/Tpk1VdqDJnTu36tBHxomfyCizZMmiOrXjxo2r75Nq1aqJj4+P+qzRgY3MB8ujPw2ZHrIXLePA54fPDp+FPZ8fORaDQjRzd3dXabN1UEAjjD/+0Ck8Ok7RcGLIHlLry5cvy4ULF+TYsWM2R6mEhoY5PBcvXlQlCPwRW0M5AA84dOiQ+kPGNmsNDhpxBKgDBw7YXO+LFy/k9OnTqtPU+v2g5q/V/dFYoBymBQSt8UJpBoHq6dOn+vTQjQX6RFByiC5nz56VAQMGSIMGDcLtWP7zzz/V+8LnZt3wauUlBCpbQQGBFw8N9ofWgIYHQRmlNyx78OBBVarLlClTmPWGhu2y1eCfO3dO/zfmoxQJ+E6hnLdnzx5VnsKBBPop0GmP7xYCtDV85hkyZFCfHcqNKB317NnT8H7QH4bPVRslhX4RHLygDIUAhwCPEVahv+fkWhgUYgACAP6gMAoJ9Vz88aND0RY/Pz+ZMmWK3Lx5Ux2ZoqFHIx0Rb6spo4MWkKG8bRnUlvEIzfpI2xqOAtHgvG29WCZVqlRhpmManqvVnCH0aCIccUbXuHYExW7dukn27Nn1xvJt+yq8Yb/I6GxB5oF6uQaN6m+//fbWbRo9erQKBMim+vXrJ/3791ejiKwbX6wndGBEULXOsFatWqUe1pIkSaJq+9ZwdI+AgMwPQVE7ig/v80HWhAc+g7ctAzgIQABDHwgyLWSQ2Ha8r+geGEDvD4NCDKhQoYL6A0W2gIYbKTY6L0M7cuSIKp2gExZH78gcACUW607ZyNBGOaEj2xqGKeJIH2WMZMmSqdEpKI+EFrpDXIOjfxwJhl7vy5cvVeaBTlAMo0QZKbR///1X/UyRIkW4De27aEehoY+mrbMPwNEwOs2xXchOrIduhrevcE4ARvyEZqtxBAR+lE40KJW8zYYNG1QnOBpNHFkjg0GwQoOKzMs6Q0HZJnQWYd3go8QWUfjuoRMd2Sg+G8Dng2AZ+vPB6+F7gf0c3meIgxcNMg48ECj27dsn8+bNU4EOpVLt+0yuhaOPYgAaB/zRo46N0TUom4RXtkDjhgZB+wPCaBetdKM1fDh6thf+4NH4hj434pdfflFHxOhTQOkIQ2iRnaDBwQMNCPoYUIe3BcEOy4deL8oUWC8a+5IlS6r51hkB3hfKaHiNdzWeb6OVpJCFaXAOh3a0r8F4/ZMnT6r697uG6SKQYfTP7du39f2ABwIjsrjwRs0g2Fsv/7YTB9FPgBo+Si5a+Q7nH6Dkgho/vgsaBBo0vBilZL0PrfclyowRdeLECZWJoMHHe8X+R4AKfYCCUV4YZYQDGXwP8N21Hn2Fhh/BSOsbQ/aLwAsIJMiQcf4HSl1a0I/Md5cci5lCDEH6jKGe+KPQOi9DK1y4sF5SQIcxUnuUElAHB6T9aARxJIujNtRy39aPYA2NAIIN1o1SD44+0c+ARhKNDo4Y8QeMYaXYTox7x9E0asQ7duxQy4UHQ0hRlkEHJmr12DY0ngiE6LDEETSCBMoVCBRocH/88Ud15IsyRlSgoxjltfHjx0ufPn1UhoBttT56RVDDEXn79u1VeQp1dA0aRHSAWkPw7Nixo+o8RSOM10CAwO84YsZ5BFGBrAX1fOwHZIHWDeW4ceNUHR5H1xg+jM8bBwgoL+H91a9fX3WAo78Az0OgQ2cwhvxinjVsu/V7xeuinIXlsQ6tJIjPBNkTtgd9BAh6eK85c+ZU/QmAjn4ELyyL4IWDCGQvWgYGCHAIvjj5Dtkx+jCw3ci2tH2G7y4yU/RV4Pse0dIoOdB7GeNkoiGpGgwJxHBLDOMLb+ikNmy0SpUqashqxYoV1TwM4cRwxd9//10tc+7cOUvNmjXV8L85c+bowzkxPNNa6CGpsHbtWkudOnXUc/E6vr6+asii5uTJk5YOHTqoIaQYTti0aVM1BPFdMBQVQ1mx3RUqVFDDSp8+farPP336tKVjx45qnVh3mzZt1JBcTXjvIfRQ0dC/w+7du9V+xXuqXr26xc/PTw2d1PYrPges29ZDW5et9eKzqF27tlpvmTJlLF999ZXl+vXrlqj65ptv1Gtj6LAtGA6M+dpQTg2G1s6cOVMNUS1evLgaIov3+/XXX6vhntZsvWcsj89+9uzZ6vtobfny5fp7xbDRkSNHWh48eGBYBsN3W7RoYSlcuLClRIkSlq5du1oCAgIMy2A4KtaDZTCstU+fPpZr167p8zFsFcOVtSHZ5Pzi4H+ODEpEROQ8WPAjIiIdgwIREekYFIiISMegQEREOgYFIiLSMSgQEZGOQYGIiMx3RnOioj0dvQn0HgX9MYP720QSx4/z3tqG53/OlNjMNEGBiMimOCyYWGNQICJz4/0fDBgUiMjcmCkYMCgQkbkxUzBgUCAic2OmYMCgQETm5vb2+2qbDYMCEZkby0cGDApEZG4sHxkwKBCRuTFTMGBQICJzY6ZgwKBARObGTMGAQYGIzI2ZggGDAhGZG4OCAYMCEZmbW+SvsBobMSgQkbnx5DUDBgUiMjeWjwwYFIjI3Dj6yIBBgYjMjZmCAYMCEZkbMwUDBgUiMjdmCgYMCkRkbswUDBgUiMjcmCkYMCgQkbkxUzBgUCAic3NjM2iNe4OIzI2ZggGDAhGZG/sUDBgUiMjcmCkYMCgQkbkxUzBgUCAic2OmYMCgQESmFodBwYBBgYhMjUHBiEGBiMyNN14zYFAgIlNzc3Nz9CY4FQYFIjI1lo+MGBSIyNQYFIwYFIjI3NinYMCgQESmxkzBiEGBiEyNQcGIQYGITI1BwYhBgYhMjUHBiEGBiMyNHc0GDApEZGrMFIwYFIjI1HhGsxGDAhGZG8tHBrzoBxGJ2ctH9jyiy5w5c6R169aGacOGDZM8efIYHpUrV9bnh4SEiI+Pj5QvX148PT2lU6dOcvXqVcM6zpw5I61atVLz8dwlS5bYtV0MCkRkao4ICsuWLZNp06aFmX7u3Dnp2rWr7Nu3T3+sXr1an+/r6yvLly+XMWPGyIoVK1SQ6Nixo7x69UrNv3//vrRr104yZ84sa9askR49esikSZPUvyOK5SMiMrX32dF8+/ZtGTFihBw+fFiyZs1qmGexWOT8+fPSuXNnSZ06dZjnouFfuHCh9OvXTypWrKimTZ06VWUN27Ztk7p168qqVaskfvz4Mnr0aIkXL57kyJFDLl++LHPnzpXGjRtHaBuZKRCRqb3PTOHUqVOq0fbz85MiRYoY5l25ckWePXsm2bNnt/ncs2fPytOnT8Xb21uf5uHhIfnz5xd/f3/1+5EjR8TLy0sFBE3p0qXl0qVLcvfu3QhtIzMFIjI3O9v5KlWqvHX+zp07w52HGr91H4G1gIAA9XPp0qWyZ88eNSqqQoUK0rdvX0mWLJncunVLzU+fPr3heWnSpNHn4Wfu3LnDzIebN29KqlSp3vn+GBSIyNSc5TyFgIAAFQjQiH///fcqc5gwYYIEBgbK4sWL5fnz52q5BAkSGJ6XMGFCefjwofr3ixcvbM6Hly9fRmg7GBRcRIY0H8iR1UOkad95svdooD69VvmCMqRzTSmYK4MEPXgia7f/KaN8N8jT5/91PIXW7bOPpU/rypK3zgjD9ATx46npLet6ScZ0KeT67QeyYrO/TFq4XV4Hv4nx90cRg47FNT+vkp9XLJdr167Jhyk/lIqVqkjXHr0kadKkapkrVy7L5O++lWPHjkq8uHGlavWa0ufLfvp8ilpQ2PmWTCAqunXrJi1atJAUKVKo33HEj76Fpk2byt9//y3u7u5634L2b62xT5Qokfo3pmudztbzIXHixBHaDgYFF5Ax7Qfi59tDPkhm/FDrVyosP03qKHuOBEqrgQslQfy4MqhTTdlcpLdUajdF3rwJMSzfpEZx+e7LRnLj3wdhXmPSgE+lRZ2SMn7eFjly6rIUz59ZhnSuLZnTfyjdRi2P8fdIEbNo4XzxnTFdPm/bXrxKe8uVy5fU7+cDA2X2vAXy5PFj6dK+raRMlUpGjxsv9+8FybQpk+TG9Wsya8587mYb4rg5R6bg5uamBwRNrly59LKQVja6c+eOGl2kwe8Yugrp0qVTv1vTfk+bNm2EtoNBwcmPYHDk/m3fhjaPZoZ2rS1nL96W+j189aP5/cf+kVO/jpTP65eWH9YdUNNSp0gqX3evKx0/LSdBD56GWc+HyZNIh0ZlZNj0X2Tqkv+Ogn7/47/65tg+DWS4j5/cvf8kht8tRSRLQFBo3KSZ9O77lZpW2ruMJE/+gQzq/6WcPnVSDh08IA8ePpDlP6/VG5g0adNJr26d5fixY+JZrBh3tJOWjwYMGKAa8EWLFunTkCFAzpw5JVOmTCrbw8glLSg8evRITp8+rc5LgJIlS6qhqm/evJG4ceOqaYcOHZJs2bJJypQpI7QdHH3kxArl+khmDP1Mlm/8QzoMXxxmft5s6WTHwTOG8s6de4/l3MVbUqt8AX3agA41pFqZfPLZV/Nk057/vmTWkiVxl3mr98mG3cZ55y7dVj+zZYjYl4li1tMnT6RO3fpSq3Zdw/Ss2f4brXLt6lU5uH+fFCtW3HDE6V2mrCRJkkT27d3Nj8iJTl4LrUaNGnLw4EGZOXOm6k/YvXu3DBkyRA01xdBS9BWg8cd5ByhhYTQSOqGRHVSvXl2tA8NOnzx5IkOHDlXDW9euXauCTJcuXSSiHJopBAcHq/G1GE6FnnHUwlAbQ5qDiIc3qkU7M7p6674UrD9Krt95IOWL/5dGWsNRP8o71uLFc1N9Augj0KDBHzxtnQQHh0idjwuFWc/lG0HyxberwkyvV7GIvHodLIGXjekoOUYyDw8ZOGRYmOm//7ZD/cyRM6dcvHBBqtesZZiPv6GPMmSUS5cuvrdtdSXOkilUqVJFndCGcwrmzZunRhzVq1dPvvjiC32Z3r17q3YTZz6jUxnt5IIFC9QwV0A2MH/+fBk3bpw0bNhQ9UkgA8G/nT4ooJOsQ4cO6mQOjLNFj3vy5MlVpwgiICLcjBkz1Bv86KOPxIzuP3qmHuFZvP6g6kP4qm1VWfzLIUmUML6M6FFXkidNJE+f/f9Ig4D/HfHbA/0Vrep5yfcr98iDx/+NeiDn8/eJv+SHBfOkQsVKkjNXbnny5LHNDmVkCsg0yHmCwvjx48NMq1WrlnqEBwG+f//+6hGewoULy8qVKyO9XQ4LCjjjLmPGjOoUbkTE0FArQ2qE5TA8i8IaO2eTygzQX4DaP47qF649IBt+PyF5sxvHMtvjk8pFZNE3beXA8QsyZNp67nonhT6C3j27qixg1Nhv1LSQEEu4y/NqoOFwjkTBaTgsKKBkhA4RWwFBO1MP0bBly5bvfdtcBUYXoRN47PebJFvGVHLzzkN5+OS5bF/whdx/FLZDOSJ6taykOrYxoqnpl3Pl5avgaN9uirqtmzfJiGGDJXOWrDJrzjz54IP/+hCSJkuqznoNDVlCmjQRG31iNs5SPnIWDutoRjBA6ehtbty4YRiPS0boZ6jqnU813Gcv3FIBIW5cNymQ8yM5fsZ45cSImDzgU5nQr7Gs3nZMPunpK0+sSlDkPJb8sEAGD/hKChfxlAWLf5TUqf87YxWyZs0mV69cMSyPkSjXr1+TbOFcPsHsnKWjWcweFD799FMZNGiQqn3hgk3aCRf4iUvB4qp+6EFv1KiRozbR6TWq6im+w5urEpKmzSfeksIjsfj9fsKudY3uVV+6N68o05fulLZDFvGENSe1etUKmTp5olSrUUtlCKEz7dJlysrRI/5y7949fdrBA/vVNXUwj8JCO2/PI7ZzWPmoV69eqsaJ07jxhbXVMYbSUZ8+fRyyfa4Ao4raNSoj80a1lsW/HJTCuTPKmN715eetR2Xf0fMRXk/h3BlUZ/WRk5fUGdFehYxXbzxz4ZY8fvoiBt4B2ePu3X9l8oTx8lGGDPJZi5Zy5vRpw/yMmTJLk2bNZcXyH6Vbp/bSpVsPefDggUyfMknKlq8gnkV5joItbk5y8pqYPSggDevZs6caP4ubQqCUhGt7oFyEcbd58+YNcw0PMjr9z01p1HuOjO5dX9ZM6yq3gx7Jd/O3yoSFW+3aVZ9U8VQBukTBrLJ7Sb8w86t3nG64tAY5xr49e9QwxBvXr0v7z8P2taGzuX6DRjJv4WKZ+N23MnRQf0mcOIlUq1FD+vYb4JBtdgVmKAnZI44FF/E2gURFezp6E+g9CvpjBve3iSSOH/mGPe8g+w6izo6vIbEZL3NBRKbG8pERgwIRmRqrR0YMCkRkauxTMGJQICJTY6ZgxKBARKbGTMGIQYGITI1BwYhBgYhMjaOPjBgUiMjU2KdgxKBARKbG8pERgwIRmRozBSMGBSIyNWYKRgwKRGRqzBSMGBSIyNSYKRgxKBCRqTFTMGJQICJTY6ZgxKBARKbGTMGIQYGITI1nNBsxKBCRqbF8ZMSgQESmxqBg5CZ2mjlzpty+fdvmvGvXrsno0aPtXSURkUP7FOx5xHZ2B4VZs2aFGxT++usv+fnnn6Nju4iI3lumYM8jtotQ+eizzz5TDT5YLBZp1qxZuMsWKlQo+raOiCiGmaCdj/6gMHbsWNmyZYsKCMgUGjduLOnSpTMs4+bmJh4eHlK9enX7toCIyIHMcPQf7UEhZ86c0rNnT30HNmnSRNKmTWvXCxEROSPGhCiOPtKCQ1BQkLx69UplDxASEiLPnz+XI0eOSPPmze1dLRGRQ7gxKkQtKJw9e1b69esn//zzj835yCQYFIjIVfDktSgGhQkTJsjDhw9l4MCBsmvXLkmQIIFUqlRJ9uzZox5Lliyxd5VERA7jxi6FqA1JxSikPn36SNu2baV27dqqZNSiRQv5/vvvpWrVqrJ06VJ7V0lE5DAckhrFoIB+hKxZs6p/4yfKSZpGjRrJ8ePH7V0lEZHD8OS1KAaFjz76SK5evaoHhSdPnqgzmQGlJJSWiIhcRRw7/4vt7A4KOA9h8uTJsnXrVjUsNXv27DJt2jQ5d+6cLFy4UDJlyhQzW0pEFEN9CvY8Yju3yAxJLVasmKxevVr9PnjwYNm+fbs0aNBADh06JL169YqJ7SQiihHsU4ji6CP0Kfj4+Mjr16/V7+XLl5cNGzbIyZMnpUCBApI5c2Z7V0lE5DA8TSGKmQJGHG3atEnix4+vT0PJqFatWgwIROSSJ6/Z84jtIpUppEiRIma2hojoPePJa1EMCp9//rnqWHZ3d5e8efNKokSJ7F0FEZHTMMHBf8wGhV9++UVu3LihTlgLr9Pm9OnT9q6WiMghzFASitGgUL9+fXufQkTktBgSoukqqUREsQHvpxDFoAAvX75UJ6uFd+lsXEWViMgVmOGEtGgPCoGBgZIrVy7178OHD6sL4oV3OYskSZIwKBCRy2CmEInzFDp27CgjR45U/546daoakjp9+nR1yQtcGXXOnDnSunVrdUvOefPmRWSVRESmviDenP+1m9bOnDkjrVq1Ek9PT6lcuXKYWxGgIoOTh3HSMJbp1KmTfi26iK4jWoICVrpy5Uq5c+eOKhuhXwEBAS94/fp1qVChggwZMkRatmwpvr6+dm0AEZHZLnOxbNkyNbTf2v3796Vdu3bqJOA1a9ZIjx49ZNKkSerfGrSvy5cvlzFjxsiKFStUkMBBO0r5EV1HtJSPcE4CoM8AG6HdnxlXScUd2DANWQLOaua1j4jIlcR9j50Kt2/flhEjRqgyvHYLAs2qVavUlSJGjx4t8eLFkxw5csjly5dl7ty50rhxY9Xw46Kj6LOtWLGiXrlB1rBt2zapW7fuO9cRbZnCoEGDpHDhwpIlSxYVgZAtAN4UOp3Pnz+vfsf1kJ4+fWrvfiIicpg4dj6i4tSpU6rR9vPzkyJFihjmYZCOl5eXasw1pUuXlkuXLsndu3fVvWvQvnp7e+vzPTw8JH/+/OLv7x+hdURbpoBSEa6Cqp2ngHQkODhY2rRpo+pW48aNU/+eP3++5MyZM0IvTETkiievValS5a3zd+7cGe48lNzxsOXWrVuSO3duw7Q0adKonzdv3lTzIX369GGW0ea9ax2pUqWSaAkKzZs31/+N+hVGHp04cUL9Pnz4cOnQoYN0795dkiZNKrNnz47IKomInIKznND84sULdaMyawkTJlQ/UZFB+R5sLaONBn3XOmLkPAV0tFifh4DLZe/YsUMuXLigbriDwEBE5Crs7Tze+ZZMICrQd6t1GGu0hjxx4sR63y6W0f6tLaNdg+5d64iRS2ejNxs31dHupwAIBOhzYEAgIlfjLPdoTpcunRrhaU37HYN7tLKRrWW0wT/vWkeMBAXcjxkjjMqVK6d60Y8dO2bvKoiInIaz3E+hZMmScvToUXnz5o0+DXezzJYtm6RMmVJdlRoH3hi5pHn06JG6ACmeG5F1xEhQwFVSN27cqK6SihfDT5zAhhMqMPSJiMiVOEum0LhxY3ny5IkMHTpUjehcu3atLFq0SLp06aLmo68AJ6VhoA9KWBiN1LdvX5UdYDBQRNYREXEs2sWLIunvv/9Wd2LbunWr6t1GGQknujmbREV5IT8zCfpjhqM3gd6jxPEj31r3WHfGruVnNcwn0QFD/XHy79KlS/VpGMCD0Zw4+k+dOrW0b99eBQINMoApU6aoxh6dysgMvv76a8mYMWOE1xHjQQG93uhjQOTas2ePGjd78OBBcTYvgh29BfQ+vQoO4Q43EQ93u4seut7rz9q1vE+DvBKbReoqqc+ePVMjjpAh7N+/X53N/PHHH6sSEn4SEbkKXiU1ikEBV0hFRoDUpVixYuo8BVzeIlmyZPauiojI4RgUohgUcIkLXJkPZzZb17GIiFwRL50dxaCwZcuWMCdGoFecO5aIXBEzhWjoU8DZy+g/OHDggBr+9PPPP8vq1avVGc2hrw9OROTMnOUyF87C7i573MDh008/VVf7q1evnn47zrhx48o333wj69ati4ntJCKK1SevuWym8N1330nBggXVdb21m0XAsGHDVCkJN+Rp2LBh9G8pEVEMiPxg1tjJ7v1x/Phxadu2rbped+h+hNq1a6vrdhMRuQpnOaPZZTMFXIYVw1FtefDgQZjLthIROTMzlIRiNFMoW7as6mTWbuoAyBhwRyCUlMqUKWPvKomIHCaum32P2M7uTKF///7SrFkzqVmzprpqHwLC+PHj5eLFi6rTGdflICJyFcwUjOyOe7imN66UittvIgjgns247AVuGo2LNGXKlMneVRIROQz7FKLhPIUUKVKoS7YSEbk6nrwWiaDg7+8v9tBu+EBE5OziCDua7Q4KOEvZ1mUsrK+6bT0fJ7gREbkCZgqRCAo4IU1z48YNdWVU3OEHV0fFTRwwFPW3336TFStWyOjRoyOySiIip8CgEImg4OXlZcgacPLaV199ZVgGl9F2d3eXH374QZ3ERkTkCngxzyiOPsKt3ry9vW3OK1q0qAQEBNi7SiIih2YK9jxiO7uDAm4SvXfv3nAvq40hqkREriKuWxy7HrGd3UNS27VrJyNHjpQ7d+5IpUqV1PDUu3fvqoCwa9cumTp1asxsKRFRDDBBOx+zQeGzzz6T4OBgmT17tmzcuNFwUhvOZsaZzkREroKXPjKKY7EeVxqJm+08fPhQZQuJEiVSN9tZs2aNyhiczYtgR28BvU+vgkO4w03Ewz3yFyWatd++Kzv3KJtVYrNIndGswZ3W0L8wf/582b17t8ogeN9mInIlzBSiISjcu3dP3X5z1apVcv36dUmaNKm6sc4nn3wiJUqUiMwqiYgcgn0KUQgKhw4dkpUrV8qOHTvkzZs3Urx4cRUUZs2aZTiXgYjIVfAqqZEICosWLVLBAJfHzpIli3Tv3l1lBokTJ1bBgCd/EJGrYvkoEkEB90vIkyePutyFdUbw+PHjiDydiMhpMVMwilCXfZ06deTy5cvSpUsXlSVs375ddSoTEbm6uHHse8R2EcoUJk+eLE+ePJFff/1V3UinV69eahhq1apVVemI5SMiclVsv6LhPIXAwEB1PgKCRFBQkLq0BbIJPHLmzCnOiOcpmAvPUzCXqJynsOTIVbuW/7xE7L67ZJROXkMJCSeqIUDs27dPjUjKlSuX+Pn5ibNhUDAXBgVziUpQ+PHoNbuWb1U8o8RmUTp5LV68eFKtWjX1wPWP1q1bpx5ERK7CBN0E7y9TcCXMFMyFmYK5RCVTWH7MvkyhRTFmCkREsRY7mqOxfERE5Ooin2PETgwKRGRqzBSMGBSIyNR4RrMRgwIRmRrLR0YMCkRkaiwfGTEoEJGp8TwFIwYFIjI1XjrbiEGBiEzNjbmCAYMCEZkaMwUjBgUiMrU4zBQMGBSIyNSYKRgxKBCRqbFPwYhBgYhMzY1nrxkwKBCRqbFPwYhBgYhMzY1nrxkwcYqFQkJCZPEPC6RereriVaywNGlYXzZucL5bpFLk/H3iuHTt0EbKlyomNSqVk5HDBsm9oCB9fsc2LaVkkXxhHqdPneQuDydTsOe/qLh9+7bkyZMnzGPt2rVq/pkzZ6RVq1bi6ekplStXliVLloT52/bx8ZHy5curZTp16iRXr9p3j+l3YaYQC/nOmC4/LFwg3Xv2loKFCsnePbtlyMD+4hbHTWrVqevozaMoOHP6lHTr2FZKlvKWiVNnyL//3pFZPlPkypXLsnDJT4IbKZ4PPCctWreVqtVrGJ6bLVt27nsHjz46e/asJEyYUHbs2GG45lKyZMnk/v370q5dOxUMRo0aJcePH1c/kyRJIo0bN1bL+fr6yvLly2X8+PGSLl06mThxonTs2FF+/fVXSZAgQbRsI4NCLPP8+XP5cekSadm6tXTo1FlNK1XaWzUmy5ctZVBwcT5TJ0nuvPlk8vRZ4va/HlI0GpMnfCvXr12TkJA38vTpUylbvoIUKuzp6M11Ce+zTyEgIECyZs0qadKkCTNv8eLFEj9+fBk9erTEixdPcuTIIZcvX5a5c+eqoPDq1StZuHCh9OvXTypWrKieM3XqVJU1bNu2TerWjZ4DPpaPYhkcLSxZ9pN83qa9YXq8+PHl5cuXDtsuiroHD+7LsSN/yKdNm+sBASpXrS4bt+2SDBkzSsC5s2pa7jx5ucvt6FOw5xEV586dU429LUeOHBEvLy8VEDSlS5eWS5cuyd27d1WWgYDv7e2tz/fw8JD8+fOLv7+/RBdmCrFM3Lhx9QYBpQTUmtevWyuHDx6Q4SNGO3rzKArOBwSomnKKFB/KsMH9Ze/vv4nFIlKpSlXpN3CoJPPwkIBzZyRx4sQyffJE2btnlzx/9kxKeJWSvv0HS9as2bj/oyFTqFKlylvn79y5862ZQooUKaRly5Zy8eJFyZIli3Tr1k0qVKggt27dkty5cxuW1zKKmzdvqvmQPn36MMto86IDM4VYbMumjVL547LiM22ylKvwsdSpV9/Rm0RRcP/+PfVzzIih4p4woUycNlP6fNlf9u7+Xfr26qYOAgLOnpVnz56pI0j0OQwdMUauXrksndu2kn/v3OH+twGlfXsekRUcHCwXLlyQhw8fSq9evVRZCJ3FnTt3loMHD8qLFy/C9Aug/wGQ5aM0DLaWic4qADOFWKxgocKycPGPEnDunMyaOV26d+koCxYt5U1FXNTr16/Vz7z5C8iwkWPVv71KeatOyqGD+qlssFuvL6R1uw5SrHhJNb9oMZHCnkWlaYM6smLZEunVt59D34MzimtnS7/zLZnA26AsdPjwYZXNu7u7q2kFCxaUwMBAWbBggZqGfgNrWmOP7E97DpbR/q0tkyhRIokuzBRisUyZM0vxEiWlectWMnDQUDl6xF+OHT3i6M2iSEKHMpSr8F8no8a7bHn189zZ06p0qAUETcaMmSRr9hwSEHCO+96GOHY+ovoZWjfokCtXLjVUFaOJ7oTK5rTf06ZNq5eNbC2D+bEiU2jdunWEj1pDj9cl2+7duyf79+6RMuXKS8qUKfXpefPnt/mFIteRKXMW9fN1qKNJlCUgYUJ32eC3XjJnySKFixQ1LPPyxQtVyyYb3tPgo8DAQGnWrJnMnj1bSpUqpU8/efKk5MyZU/LlyycrVqyQN2/eqGwCDh06JNmyZVN/y8gIkyZNqrKNzJkzq/mPHj2S06dPq3MbYkWmUK5cOdXjHhQUJBkyZHjrgyIGf/zDhgyU9WtXG6Yf3L9f/cydOw93pYvKlj2HfPRRBtm2dZPqP9Ds+f039bNoseIy7/tZ4jNlkuF5Z8+ckmtXr0iJkv/fENH7P3ktR44ckj17djXkFO3eP//8I99++606HwGdzRh2+uTJExk6dKicP39endC2aNEi6dKli96XgMZ/0qRJqoSF0Uh9+/ZVGUb16tWj7SONY7H+djnAsmXLZPLkyeLn5ycZM2aMsdd58d/BlCmMGD5ENm/cID169ZG8+fKrktHC+XNVR/PI0ePEDF4Fh0hstHP7Vhncv69UqVZDGjRuIhf/+Udmz5wmpcuUk+8mT5eNv66XkcMGS+269dXj5s0bMsd3hqRKlVoWLVulH4HGNh7ukT++/ePCQ7uW98qePNKvhaGlaO/27t2rjvIxnBTnHZQoUULNP3HihIwbN04d/adOnVrat29vyAKQRUyZMkUFDHRMlyxZUr7++utobTsdHhSga9euKgri9O2YYqaggPLCoh8WiN8v6+XmjeuSLl16adykqbRp18Ewvj02i61BAfbu3iXz58xWZy57JE8uNWvXk249++ijUrZv3SxLFy2QixcuqA7IipWrSo8+fSV58g8ktopKUPC3MyiUjEJQcAVOERRQ5z516pRUqlQpxl7DTEGBYndQoGgOChftDArZYndQcIohqTj5wtZp30REMY2XznbCoEBE5Ci8HacRgwIRmRqDghGDAhGZGstHRgwKRGRqzBSMGBSIyNR4N04jBgUiMjdGBQMGBSIyNfYpGDEoEJGpsU/BiEGBiEyN1SMjBgUiMjdGBQMGBSIyNTfWjwwYFIjI1JgoGDEoEJG5MSoYMCgQkalxSKoRgwIRmRq7FIwYFIjI1Fg9MmJQICJzY1QwYFAgIlNjn4IRgwIRmRr7FIwYFIjI1Fg9MmJQICJTi8NUwYBBgYhMjTHBiEGBiEyN5SMjBgUiMjdGBQMGBSIyNQ5JNWJQICJTY5+CEYMCEZkaq0dGDApEZGrMFIwYFIjI5JgrWGNQICJTc2NMMGBQICJTY/nIiEGBiEyNQ1KNGBSIyNxYPjJgUCAiU2NMMGJQICJTY5+CEYMCEZka+xSMGBSIyNxYPzJgUCAiU2NMMGJQICJTc2OnggGDAhGZGmOCkVuo34mIyMSYKRCRqTFTMGJQICJT45BUIwYFIjI1ZgpGDApEZGockmrEoEBE5saoYMCgQESmxj4FIwYFIjI13nnNiEGBiMyN5SMDBgUiMjWWj4wYFIjI1Dgk1SiOxWKxhJpGREQmxWsfERGRjkGBiIh0DApERKRjUCAiIh2DAhER6RgUiIhIx6BAREQ6BgUiItIxKBARkY5BgYiIdAwKRESkY1AgIiIdgwIREekYFGKhkJAQ8fHxkfLly4unp6d06tRJrl696ujNovdgzpw50rp1a+5rijQGhVjI19dXli9fLmPGjJEVK1aoINGxY0d59eqVozeNYtCyZctk2rRp3McUJQwKsQwa/oULF0rv3r2lYsWKkjdvXpk6darcunVLtm3b5ujNoxhw+/Zt6dq1q0yaNEmyZs3KfUxRwqAQy5w9e1aePn0q3t7e+jQPDw/Jnz+/+Pv7O3TbKGacOnVK4sePL35+flKkSBHuZooS3o4zlkFGAOnTpzdMT5MmjT6PYpfKlSurB1F0YKYQyzx//lz9TJAggWF6woQJ5eXLlw7aKiJyFQwKsYy7u7v6GbpTGQEhUaJEDtoqInIVDAqxjFY2unPnjmE6fk+bNq2DtoqIXAWDQiyD0UZJkyaVw4cP69MePXokp0+flpIlSzp024jI+bGjOZZBX0KrVq3U8MQPP/xQMmTIIBMnTpR06dJJ9erVHb15ROTkGBRiIZyjEBwcLMOGDZMXL16oDGHBggVq2CIR0dvEsVgslrcuQUREpsE+BSIi0jEoEBGRjkGBiIh0DApERKRjUCAiIh2DAhER6RgUiMLB0dpkRgwKFGNwW8g8efIYHgULFlQ3/xk1apQ8fPgwRl537dq16rWuXbumfp8xY4b6PaJwifHOnTvL9evX9Wm4NPWgQYNiZHuJnAnPaKYYhZv7jBgxQv/99evX6qYwU6ZMkTNnzshPP/0kceLEidFtaNKkibpfdUQdOHBAdu/ebZg2c+ZMdU0potiOQYFiFBpST09PwzRcdgN3h/Px8ZG//vorzPzohus+4RHV4EZkBiwfkUOgjAQ3btxQZaZ+/fqpazYhQLRr106/B8SECRPk448/VsvXq1dPNm3aZFhPSEiI+Pr6qpIUbkXZvXv3MGUpW+Wj9evXS8OGDdVz8NzJkyere1Cg9DR48GC1TJUqVfSSUejyUUS2jcgVMVMgh7h48aL6mSlTJvVz8+bNUr9+fZk9e7Zq6NHJ26NHDzl27JgKFjly5JDt27dL3759VePdoEED9TxcAXbJkiXSrVs31cBjPWjg32bZsmUyevRoVVb68ssv5erVq6qBRzD54osv1LqwHSgZ2eqLiOi2EbkiBgWKUWhAccVWDRreP/74QzW6RYsW1TMGXMEVnc/abUT3798ve/fulalTp0rt2rXVNPQL4HajuCx43bp15dmzZ7J06VKVWfTs2VNfBjcUwnNtQcCZNWuWVK1aVcaOHatPx3o3btwoyZIlk8yZM6tp+fLlk4wZM9rsc3jXtsWLxz8tck385lKM8vf3lwIFChimubm5SZkyZdTRutbJnD17dsN9pQ8ePKjmoTxjHVRQxvHz85PAwED5999/Vcd1pUqVDOuvVatWuEEBGUpQUJBUq1bNML1Dhw7qERER2TYEFCJXxKBAMQoBARkAoCFNmDChumVo6JE8SZIkMfz+4MEDlWUUK1bM5nqRDeCOcpAiRQrDvNSpU4e7PVgvpEyZMpLvKGLbxqBAropBgWIUGvtChQrZ/TyUcRInTqz6C2zJkiWLnDhxQv0bR/7INEI3/LZ4eHion/fu3TNMv3//vrplKUpa0bFtRK6Ko4/IKXl5eak+AxyRI6hoj4CAANUngLINGnB3d3fZsmWL4bm7du0Kd70IHsgsQi/zyy+/qBPWUI5CeSuq20bkqpgpkFNCvR7nM2CIKR4Y4YPMAOc2oFMX958GzJs2bZokSpRISpcurU46e1tQiBs3rvTq1Uv1Z6CEhH4A9DNgvS1btpTkyZPr2QRGFFWoUEG9dmS2jcgVMSiQU8LR+ty5c2X69OkyZ84cVSJKmzatGmmE4aCaLl26qFLO4sWL1QPZw8CBA2XkyJHhrhuNP56D+1avXLlSndjWqVMn9YBSpUqpjnAMbUWnMrYjMttG5Ip4j2YiG1AaevPmDYeWkumwT4HIhnXr1qmRU9pF9YjMgkGByAac+5A1a1bVkU1kJgwKRDacPXtWXYcpVapU3D9kKuxTIAqnTyGmL+lN5IyYKRDZwIBAZsWgQEREOgYFIiLSMSgQEZGOQYGIiHQMCkREpGNQICIiHYMCERHpGBSIiEg0/wefYSYoFruOSwAAAABJRU5ErkJggg==",
      "text/plain": [
       "<Figure size 400x300 with 2 Axes>"
      ]
     },
     "metadata": {},
     "output_type": "display_data"
    },
    {
     "data": {
      "text/html": [
       "<div>\n",
       "<style scoped>\n",
       "    .dataframe tbody tr th:only-of-type {\n",
       "        vertical-align: middle;\n",
       "    }\n",
       "\n",
       "    .dataframe tbody tr th {\n",
       "        vertical-align: top;\n",
       "    }\n",
       "\n",
       "    .dataframe thead th {\n",
       "        text-align: right;\n",
       "    }\n",
       "</style>\n",
       "<table border=\"1\" class=\"dataframe\">\n",
       "  <thead>\n",
       "    <tr style=\"text-align: right;\">\n",
       "      <th></th>\n",
       "      <th>model</th>\n",
       "      <th>recall</th>\n",
       "      <th>specificity</th>\n",
       "      <th>f1_score</th>\n",
       "      <th>roc_auc</th>\n",
       "    </tr>\n",
       "  </thead>\n",
       "  <tbody>\n",
       "    <tr>\n",
       "      <th>0</th>\n",
       "      <td>Logistic Regression</td>\n",
       "      <td>0.970588</td>\n",
       "      <td>0.968944</td>\n",
       "      <td>0.680412</td>\n",
       "      <td>0.989427</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>1</th>\n",
       "      <td>Random Forest</td>\n",
       "      <td>0.955882</td>\n",
       "      <td>0.983437</td>\n",
       "      <td>0.787879</td>\n",
       "      <td>0.987418</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>2</th>\n",
       "      <td>XGBoost</td>\n",
       "      <td>0.955882</td>\n",
       "      <td>0.989648</td>\n",
       "      <td>0.849673</td>\n",
       "      <td>0.993903</td>\n",
       "    </tr>\n",
       "  </tbody>\n",
       "</table>\n",
       "</div>"
      ],
      "text/plain": [
       "                 model    recall  specificity  f1_score   roc_auc\n",
       "0  Logistic Regression  0.970588     0.968944  0.680412  0.989427\n",
       "1        Random Forest  0.955882     0.983437  0.787879  0.987418\n",
       "2              XGBoost  0.955882     0.989648  0.849673  0.993903"
      ]
     },
     "metadata": {},
     "output_type": "display_data"
    },
    {
     "name": "stdout",
     "output_type": "stream",
     "text": [
      "Modelul XGBoost a fost salvat la: models\\xgboost_model.pkl\n"
     ]
    }
   ],
   "source": [
    "# 6) Evaluăm fiecare model pe setul de test\n",
    "results = {}\n",
    "results['Logistic Regression'] = evaluate_model(models['Logistic Regression'], X_test_scaled, y_test, 'Logistic Regression')\n",
    "results['Random Forest'] = evaluate_model(models['Random Forest'], X_test, y_test, 'Random Forest')\n",
    "results['XGBoost'] = evaluate_model(models['XGBoost'], X_test, y_test, 'XGBoost')\n",
    "\n",
    "# 7) Afișăm un tabel comparativ al rezultatelor\n",
    "summary = pd.DataFrame([\n",
    "    {\n",
    "        'model': name,\n",
    "        'recall': results[name]['recall'],\n",
    "        'specificity': results[name]['specificity'],\n",
    "        'f1_score': results[name]['f1_score'],\n",
    "        'roc_auc': results[name]['roc_auc']\n",
    "    } for name in results\n",
    "])\n",
    "display(summary)\n",
    "\n",
    "# 8) Salvăm modelul XGBoost în directorul models\n",
    "xgb_path = os.path.join(models_dir, 'xgboost_model.pkl')\n",
    "joblib.dump(models['XGBoost'], xgb_path)\n",
    "print('Modelul XGBoost a fost salvat la:', xgb_path)"
   ]
  }
 ],
 "metadata": {
  "kernelspec": {
   "display_name": "Python 3",
   "language": "python",
   "name": "python3"
  },
  "language_info": {
   "codemirror_mode": {
    "name": "ipython",
    "version": 3
   },
   "file_extension": ".py",
   "mimetype": "text/x-python",
   "name": "python",
   "nbconvert_exporter": "python",
   "pygments_lexer": "ipython3",
   "version": "3.14.2"
  }
 },
 "nbformat": 4,
 "nbformat_minor": 5
}
