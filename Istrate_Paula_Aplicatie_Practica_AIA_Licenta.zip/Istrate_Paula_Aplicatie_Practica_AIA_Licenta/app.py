﻿import streamlit as st
import pandas as pd
import xgboost as xgb
import joblib
import shap
import matplotlib.pyplot as plt
import numpy as np
from scipy.optimize import differential_evolution
from datetime import datetime
from typing import Dict, List, Optional

# --- 1. Visual configuration (dark mode, tech design) ---
st.set_page_config(page_title="Dashboard Mentenanță", layout="wide")

st.markdown("""
    <style>
    .main { background-color: #0E1117; color: #FFFFFF; }
    .stApp { background-color: #0E1117; }
    h1, h2, h3 { color: #00CC00 !important; }
    .css-1r6slp0 { background-color: #1C2025; }
    div.stMetric { background-color: #1C2025; padding: 20px; border-radius: 10px; border: 1px solid #00CC00; }
    .stSlider > div > div > div > div { background-color: #00CC00 !important; }
    .stButton button { border-radius: 8px; }
    </style>
""", unsafe_allow_html=True)

# --- 2. Session state initialization ---
def init_session_state() -> None:
    """Initialize persistent state for the dashboard."""
    if 'scenario_snapshots' not in st.session_state:
        st.session_state.scenario_snapshots = []
    if 'show_shap_plot' not in st.session_state:
        st.session_state.show_shap_plot = False
    if 'show_optimization_results' not in st.session_state:
        st.session_state.show_optimization_results = False
    if 'optimization_results' not in st.session_state:
        st.session_state.optimization_results = None


@st.cache_resource
def load_model() -> Optional[xgb.XGBClassifier]:
    """Load the pre-trained XGBoost model once per user session."""
    try:
        return joblib.load('models/xgboost_model.pkl')
    except Exception as exc:
        st.error(f"Unable to load model: {exc}")
        return None


@st.cache_resource
def load_explainer(_model: xgb.XGBClassifier) -> Optional[shap.TreeExplainer]:
    """Create a SHAP explainer for the loaded model and cache it."""
    try:
        return shap.TreeExplainer(_model)
    except Exception as exc:
        st.error(f"Unable to create SHAP explainer: {exc}")
        return None


def build_input_dataframe(
    air_temp: float,
    process_temp: float,
    rotational_speed: float,
    torque: float,
    tool_wear: int,
    machine_type: str
) -> pd.DataFrame:
    """Build a standardized DataFrame from the current slider values."""
    return pd.DataFrame({
        'Air_temperature__K': [air_temp],
        'Process_temperature__K': [process_temp],
        'Rotational_speed__rpm': [rotational_speed],
        'Torque__Nm': [torque],
        'Tool_wear__min': [tool_wear],
        'Type_L': [1 if machine_type == 'L' else 0],
        'Type_M': [1 if machine_type == 'M' else 0]
    })


def estimate_failure_cause(shap_values: np.ndarray, feature_names: List[str]) -> tuple:
    """Map dominant SHAP features to one of the predefined failure modes."""
    abs_shap = np.abs(shap_values)
    top_2_indices = np.argsort(abs_shap)[-2:][::-1]
    top_features = {feature_names[idx] for idx in top_2_indices if idx < len(feature_names)}

    if 'Air_temperature__K' in top_features or 'Process_temperature__K' in top_features:
        return "HDF", "Heat Dissipation Failure - Thermal stress detected"
    if 'Torque__Nm' in top_features and 'Tool_wear__min' in top_features:
        return "OSF", "Overstrain Failure - Mechanical stress and wear combined"
    if 'Rotational_speed__rpm' in top_features and 'Torque__Nm' in top_features:
        return "PWF", "Power Failure - Speed and torque mismatch"
    if 'Tool_wear__min' in top_features:
        max_idx = np.argmax(abs_shap)
        if max_idx < len(feature_names) and feature_names[max_idx] == 'Tool_wear__min':
            return "TWF", "Tool Wear Failure - Tool degradation critical"
    return "RNF", "Random Failures - Multiple factors contributing"


def generate_simple_human_factors(
    shap_values: np.ndarray,
    feature_names: List[str],
    input_data: pd.DataFrame
) -> str:
    """Generate a concise, human-centered SHAP factor summary."""
    abs_shap = np.abs(shap_values)
    top_indices = np.argsort(abs_shap)[-3:][::-1]
    factors_text = "**Key Factors:**\n\n"
    max_shap = np.max(abs_shap) if abs_shap.size else 0.0

    for idx in top_indices:
        if idx >= len(feature_names):
            continue
        feature_name = feature_names[idx]
        shap_val = shap_values[idx]
        display_name = feature_name.replace('_', ' ').replace('__', ' ').strip()
        contribution_pct = (abs(shap_val) / max_shap * 100) if max_shap > 0 else 0

        if contribution_pct > 70:
            status = "Critical"
        elif contribution_pct > 40:
            status = "High"
        else:
            status = "Normal"

        impact = "Increases risk" if shap_val > 0 else "Decreases risk" if shap_val < 0 else "Neutral"
        factors_text += f"- **{display_name}**: {status} ({impact})\n"

    return factors_text


def generate_risk_summary(
    shap_values: np.ndarray,
    feature_names: List[str],
    input_data: pd.DataFrame,
    risk_percentage: float
) -> tuple:
    """Produce the risk summary text, failure cause, and human factor summary."""
    risk_level = "HIGH" if risk_percentage > 50 else "MODERATE" if risk_percentage > 30 else "LOW"
    cause_code, cause_description = estimate_failure_cause(shap_values, feature_names)
    human_factors = generate_simple_human_factors(shap_values, feature_names, input_data)
    risk_analysis = f"**Risk Level:** {risk_level} ({risk_percentage:.1f}%)\n\n"
    risk_analysis += f"**Estimated Cause:** {cause_code} - {cause_description}"
    return risk_analysis, cause_code, cause_description, human_factors


def create_scenario_snapshot(
    air_temp: float,
    process_temp: float,
    tool_wear: int,
    rotational_speed: float,
    torque: float,
    machine_type: str,
    risk_percentage: float,
    cause_code: str
) -> Dict:
    """Create a timestamped snapshot of the current scenario state."""
    return {
        'timestamp': datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        'air_temp': air_temp,
        'process_temp': process_temp,
        'tool_wear': tool_wear,
        'rotational_speed': rotational_speed,
        'torque': torque,
        'machine_type': machine_type,
        'risk_percentage': risk_percentage,
        'cause_code': cause_code
    }


def format_snapshot_for_display(snapshot: Dict) -> Dict:
    """Format a scenario snapshot for display in the history table."""
    params_str = (
        f"Air: {snapshot['air_temp']:.1f}K | "
        f"Process: {snapshot['process_temp']:.1f}K | "
        f"Wear: {snapshot['tool_wear']}min | "
        f"Speed: {snapshot['rotational_speed']:.0f}rpm | "
        f"Torque: {snapshot['torque']:.1f}Nm | "
        f"Type: {snapshot['machine_type']}"
    )
    risk_level = "HIGH" if snapshot['risk_percentage'] > 50 else "MODERATE" if snapshot['risk_percentage'] > 30 else "LOW"
    return {
        'Timestamp': snapshot['timestamp'],
        'Parameters': params_str,
        'Risk Level': f"{risk_level} ({snapshot['risk_percentage']:.1f}%)",
        'Estimated Cause': snapshot['cause_code']
    }


def create_shap_explanation(
    explainer: shap.TreeExplainer,
    shap_values_computed,
    input_data: pd.DataFrame,
    feature_names: List[str]
) -> Optional[shap.Explanation]:
    """Build a SHAP Explanation object for the waterfall plot."""
    try:
        shap_values_for_plot = shap_values_computed[1] if isinstance(shap_values_computed, list) else shap_values_computed
        expected_value = explainer.expected_value[1] if isinstance(explainer.expected_value, list) else explainer.expected_value
        shap_values_single = shap_values_for_plot[0] if isinstance(shap_values_for_plot, np.ndarray) and shap_values_for_plot.ndim > 1 else shap_values_for_plot
        return shap.Explanation(
            values=shap_values_single,
            base_values=expected_value,
            data=input_data.values[0],
            feature_names=feature_names
        )
    except Exception as exc:
        st.error(f"Could not create SHAP explanation: {exc}")
        return None


def render_shap_plot(explanation: shap.Explanation) -> None:
    """Render the SHAP waterfall visualization inside the page."""
    st.markdown("### SHAP Waterfall Visualization")
    fig = plt.figure(figsize=(14, 7), facecolor='#0E1117')
    plt.style.use('dark_background')
    shap.plots.waterfall(explanation, show=False, max_display=8)
    st.pyplot(fig, use_container_width=True)
    plt.close(fig)

    if st.button("Close SHAP View", key="close_shap_btn", use_container_width=False):
        st.session_state.show_shap_plot = False


def generate_action_commands(
    current_rpm: float,
    optimal_rpm: float,
    current_torque: float,
    optimal_torque: float
) -> str:
    """Generate a short list of recommended parameter adjustments."""
    actions = []
    rpm_diff = optimal_rpm - current_rpm
    if abs(rpm_diff) > 1:
        if rpm_diff > 0:
            actions.append(f"Increase Rotational Speed by {rpm_diff:.0f} rpm (from {current_rpm:.0f} to {optimal_rpm:.0f})")
        else:
            actions.append(f"Decrease Rotational Speed by {abs(rpm_diff):.0f} rpm (from {current_rpm:.0f} to {optimal_rpm:.0f})")
    torque_diff = optimal_torque - current_torque
    if abs(torque_diff) > 0.1:
        if torque_diff > 0:
            actions.append(f"Increase Torque by {torque_diff:.2f} Nm (from {current_torque:.2f} to {optimal_torque:.2f})")
        else:
            actions.append(f"Decrease Torque by {abs(torque_diff):.2f} Nm (from {current_torque:.2f} to {optimal_torque:.2f})")
    if not actions:
        return "Current settings are already optimal. No adjustments needed."
    action_text = "**Recommended Actions:**\n\n"
    action_text += "\n".join([f"{i + 1}. {action}" for i, action in enumerate(actions)])
    return action_text


def suggest_optimal_settings(
    model,
    current_rpm: float,
    current_torque: float,
    air_temp: float,
    process_temp: float,
    tool_wear: int,
    machine_type: str,
    input_data: pd.DataFrame
) -> Dict:
    """Optimize rpm and torque to minimize predicted failure probability."""
    bounds_list = [(1100, 3000), (10.0, 80.0)]

    def objective_function(params):
        rpm, torque = params
        opt_data = pd.DataFrame({
            'Air_temperature__K': [air_temp],
            'Process_temperature__K': [process_temp],
            'Rotational_speed__rpm': [rpm],
            'Torque__Nm': [torque],
            'Tool_wear__min': [tool_wear],
            'Type_L': [1.0 if machine_type == 'L' else 0.0],
            'Type_M': [1.0 if machine_type == 'M' else 0.0]
        })
        return model.predict_proba(opt_data)[0][1]

    try:
        result = differential_evolution(
            objective_function,
            bounds_list,
            seed=42,
            maxiter=300,
            popsize=15,
            atol=1e-5,
            tol=1e-5,
            workers=1,
            updating='deferred'
        )
    except Exception as exc:
        return {'success': False, 'message': f"Optimization error: {exc}"}

    if not result.success and result.fun >= objective_function([current_rpm, current_torque]):
        return {'success': False, 'message': 'Optimization did not find a better configuration.'}

    optimal_rpm, optimal_torque = result.x
    current_risk = model.predict_proba(input_data)[0][1] * 100
    opt_data = pd.DataFrame({
        'Air_temperature__K': [air_temp],
        'Process_temperature__K': [process_temp],
        'Rotational_speed__rpm': [optimal_rpm],
        'Torque__Nm': [optimal_torque],
        'Tool_wear__min': [tool_wear],
        'Type_L': [1.0 if machine_type == 'L' else 0.0],
        'Type_M': [1.0 if machine_type == 'M' else 0.0]
    })
    optimal_risk = model.predict_proba(opt_data)[0][1] * 100

    return {
        'success': True,
        'optimal_rpm': optimal_rpm,
        'optimal_torque': optimal_torque,
        'current_risk': current_risk,
        'optimal_risk': optimal_risk,
        'risk_reduction': current_risk - optimal_risk
    }


init_session_state()
model = load_model()
if model is None:
    st.stop()

explainer = load_explainer(model)
if explainer is None:
    st.stop()

st.title("Predictive Maintenance Decision Support System")
st.markdown("**Human-Centered XAI for Equipment Reliability**")

col1, col2 = st.columns([1, 1])

with col1:
    st.subheader("Equipment Parameters")
    st.markdown("### Physical Equipment State")
    air_temp = st.slider("Air Temperature [K]", min_value=290.0, max_value=310.0, value=298.1, step=0.1, help="Equipment environmental condition")
    process_temp = st.slider("Process Temperature [K]", min_value=300.0, max_value=320.0, value=308.6, step=0.1, help="Equipment internal temperature")
    tool_wear = st.slider("Tool Wear [min]", min_value=0, max_value=300, value=142, step=1, help="Cumulative tool wear indicator")
    st.markdown("### Operational Control")
    rotational_speed = st.slider("Rotational Speed [rpm]", min_value=1100, max_value=3000, value=1551, step=10, help="Operational speed")
    torque = st.slider("Torque [Nm]", min_value=10.0, max_value=80.0, value=42.8, step=0.5, help="Force applied")
    type_product = st.selectbox("Machine Type", ['L', 'M', 'H'], help="Machine product type")

with col2:
    st.subheader("Risk Assessment & Explainability")
    input_data = build_input_dataframe(air_temp, process_temp, rotational_speed, torque, tool_wear, type_product)
    try:
        proba = model.predict_proba(input_data)[0][1] * 100
    except Exception as exc:
        st.error(f"Prediction error: {exc}")
        st.stop()

    st.metric(label="Failure Risk", value=f"{proba:.2f}%")
    if proba > 50.0:
        st.error(f"CRITICAL: Equipment failure risk is {proba:.1f}%. Immediate action required.")
    elif proba > 30.0:
        st.warning(f"CAUTION: Equipment failure risk is {proba:.1f}%. Consider operational adjustments.")
    else:
        st.success(f"OPTIMAL: Equipment operates safely at {proba:.1f}% failure risk.")

    st.markdown("---")
    st.subheader("Risk Analysis")
    shap_values_computed = explainer.shap_values(input_data)
    shap_values_array = shap_values_computed[1] if isinstance(shap_values_computed, list) else shap_values_computed
    shap_values_flat = shap_values_array[0] if isinstance(shap_values_array, np.ndarray) and shap_values_array.ndim > 1 else np.asarray(shap_values_array).flatten()
    feature_names = list(input_data.columns)
    risk_analysis, cause_code, cause_description, human_factors = generate_risk_summary(
        shap_values_flat,
        feature_names,
        input_data,
        proba
    )
    st.markdown(risk_analysis)
    st.markdown(human_factors)

    if proba > 20.0:
        st.markdown("### Feature Impact Breakdown")
        if st.button("View SHAP Waterfall Below", key="shap_waterfall_btn", use_container_width=True):
            st.session_state.show_shap_plot = True

    st.markdown("---")
    col_save_1, col_save_2 = st.columns([2, 1])
    with col_save_1:
        st.markdown("### Scenario Tracking")
    with col_save_2:
        if st.button("Save Current Scenario", key="save_scenario_btn", use_container_width=True):
            snapshot = create_scenario_snapshot(
                air_temp,
                process_temp,
                tool_wear,
                rotational_speed,
                torque,
                type_product,
                proba,
                cause_code
            )
            st.session_state.scenario_snapshots = st.session_state.scenario_snapshots + [snapshot]
            st.success("Scenario saved to history!")

st.markdown("---")
st.subheader("What-If Analysis & Optimization")
st.markdown("**Suggest Optimal Settings** finds the best combination of *Rotational Speed* and *Torque* to minimize failure risk while respecting operational constraints.")
col_opt_1, col_opt_2, col_opt_3 = st.columns([1, 1, 2])
with col_opt_1:
    optimize_button = st.button("Suggest Optimal Settings", key="optimize_btn", type="primary", use_container_width=True)
with col_opt_2:
    if st.button("Reset Results", key="reset_btn", use_container_width=True):
        st.session_state.show_optimization_results = False
        st.session_state.optimization_results = None
if optimize_button:
    with st.spinner("Optimizing equipment parameters..."):
        st.session_state.optimization_results = suggest_optimal_settings(
            model,
            rotational_speed,
            torque,
            air_temp,
            process_temp,
            tool_wear,
            type_product,
            input_data
        )
        st.session_state.show_optimization_results = True

if st.session_state.show_optimization_results and st.session_state.optimization_results:
    results = st.session_state.optimization_results
    if results['success']:
        st.success("Optimization successful. Recommended parameter adjustments found.")
        action_commands = generate_action_commands(
            rotational_speed,
            results['optimal_rpm'],
            torque,
            results['optimal_torque']
        )
        st.markdown(action_commands)
        comparison_data = {
            'Parameter': ['Rotational Speed (rpm)', 'Torque (Nm)', 'Failure Risk (%)'],
            'Current Value': [f"{rotational_speed:.0f}", f"{torque:.2f}", f"{results['current_risk']:.2f}"],
            'Optimal Value': [f"{results['optimal_rpm']:.0f}", f"{results['optimal_torque']:.2f}", f"{results['optimal_risk']:.2f}"],
            'Change': [f"{results['optimal_rpm'] - rotational_speed:+.0f}", f"{results['optimal_torque'] - torque:+.2f}", f"{results['optimal_risk'] - results['current_risk']:+.2f}"]
        }
        comparison_df = pd.DataFrame(comparison_data)
        st.markdown("**Comparison Table:**")
        st.dataframe(comparison_df, use_container_width=True, hide_index=True)
        st.info(f"Expected Risk Reduction: {results['risk_reduction']:.2f}%\n\nCurrent Risk: {results['current_risk']:.2f}% → Optimal Risk: {results['optimal_risk']:.2f}%")
    else:
        st.error(f"Optimization failed: {results.get('message', 'Unknown error')}")

if st.session_state.show_shap_plot:
    explanation = create_shap_explanation(explainer, shap_values_computed, input_data, feature_names)
    if explanation is not None:
        render_shap_plot(explanation)

st.markdown("---")
st.subheader("Scenario History")
st.markdown("Track and compare all saved equipment configurations and their risk assessments.")
if st.session_state.scenario_snapshots:
    history_display = [format_snapshot_for_display(snapshot) for snapshot in st.session_state.scenario_snapshots]
    history_df = pd.DataFrame(history_display)
    st.dataframe(history_df, use_container_width=True, hide_index=True)
    col_clear_1, col_clear_2, col_clear_3 = st.columns([3, 1, 1])
    with col_clear_2:
        if st.button("Clear History", key="clear_history_btn", use_container_width=True):
            st.session_state.scenario_snapshots = []
            st.experimental_rerun()
else:
    st.info("No scenarios saved yet. Click 'Save Current Scenario' in the Risk Assessment section to start tracking.")
st.markdown("---")
st.caption("Thesis Project: Human-Centered XAI Decision Support System for Predictive Maintenance | Powered by XGBoost + SHAP + Streamlit")
